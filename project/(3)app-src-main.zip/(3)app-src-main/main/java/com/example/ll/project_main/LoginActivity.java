package com.example.ll.project_main;


import android.app.ProgressDialog;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ll.project_main.WebServiceGet;


public class LoginActivity extends AppCompatActivity{
    private EditText username;   //用户名文本框
    private EditText password;   //密码文本框
    private Button btnLogin;     //登录按钮
    private Button btnRegister;  //注册按钮
    private TextView infotv;
    private String info; //服务器返回的数据
    //提示框
    private ProgressDialog dialog;
    private LinearLayout mLinearLayout;
    private GestureDetector mGestureDetector;

    private boolean flagReceiveRegis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        mLinearLayout =  (LinearLayout) findViewById(R.id.background);
        mLinearLayout.getBackground().setAlpha(150);

        username = (EditText) findViewById(R.id.et_user);  //获取用户名文本框
        password = (EditText) findViewById(R.id.et_password);  //获取密码文本框
        btnLogin = (Button) findViewById(R.id.btn_login);   //获取登录按钮

        btnRegister = (Button) findViewById(R.id.btn_register);  //获取注册按钮


        infotv = (TextView)findViewById(R.id.info);   //获取服务器返回数据文本框

        //登录按钮监听器
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //设置提示框
                dialog = new ProgressDialog(LoginActivity.this);
                dialog.setTitle("正在登录");
                dialog.setMessage("请稍后");
                dialog.setCancelable(false);//设置可以通过back键取消
                dialog.show();

                //设置子线程，分别进行Get和Post传输数据
                new Thread(new MyThread1()).start();
//                new Thread(new MyThread2()).start();

                Intent intent = new Intent(LoginActivity.this,
                        MainActivity.class);
                //声明一个编辑框和布局文件中id为edit_message的编辑框链接起来。
                EditText editText =findViewById(R.id.et_user);
                //把编辑框获取的文本赋值给String类型的message
                String message = editText.getText().toString();
                //给message起一个名字，并传给另一个activity
                intent.putExtra("phone",message);

                //启动意图
                startActivity(intent);

            }
        });

        //注册按钮监听器
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转注册页面
                //现在没有注册页面，先跳转到首页
                Intent intent = new Intent(LoginActivity.this,Register.class);
                startActivity(intent);
            }
        });
    }
    public class MyThread1 implements Runnable{
        @Override
        public void run() {

            info = WebServiceGet.executeHttpGet(username.getText().toString(),password.getText().toString(),null);//获取服务器返回的数据

            //更新UI，使用runOnUiThread()方法
            showResponse(info);
        }
    }
    private void showResponse(final String response){
        runOnUiThread(new Runnable() {
            //更新UI
            @Override
            public void run() {
                if("false".equals(response)){
                    Toast.makeText(LoginActivity.this,"登录失败！", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(LoginActivity.this,"登录成功！", Toast.LENGTH_SHORT).show();
                }
                dialog.dismiss();
            }
        });
    }
}

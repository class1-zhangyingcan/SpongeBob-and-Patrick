package com.example.ll.project_main.Activity.ActivityIndex;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.view.animation.Transformation;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.ll.project_main.R;
import com.example.ll.project_main.bean.NaturalScene;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class SceneActivity extends AppCompatActivity{

    private TextView item_expand_textview;
    private ImageView item_expand_imageview;
    private LinearLayout description_layout;
    int maxDescripLine = 2; //TextView默认最大展示行数


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scene);
        ImageView back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SceneActivity.this.finish();
            }
        });
        MyScrollView myScrollView = findViewById(R.id.MyScrollView);
        item_expand_textview=findViewById(R.id.item_expand_textview);
        item_expand_imageview = findViewById(R.id.item_expand_imageview);
        description_layout = findViewById(R.id.description_layout);

        //折叠文本内容
        init();
        description_layout.setOnClickListener(new View.OnClickListener() {
            boolean isExpand;//是否已展开的状态

            @Override
            public void onClick(View v) {
                isExpand = !isExpand;
                item_expand_textview.clearAnimation();//清楚动画效果
                final int deltaValue;//默认高度，即前边由maxLine确定的高度
                final int startValue = item_expand_textview.getHeight();//起始高度
                int durationMillis = 350;//动画持续时间
                if (isExpand) {
                    /**
                     * 折叠动画
                     * 从实际高度缩回起始高度
                     */
                    deltaValue = item_expand_textview.getLineHeight() * item_expand_textview.getLineCount() - startValue;
                    RotateAnimation animation = new RotateAnimation(0, 180, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
                    animation.setDuration(durationMillis);
                    animation.setFillAfter(true);
                    item_expand_imageview.startAnimation(animation);
                } else {
                    /**
                     * 展开动画
                     * 从起始高度增长至实际高度
                     */
                    deltaValue = item_expand_textview.getLineHeight() * maxDescripLine - startValue;
                    RotateAnimation animation = new RotateAnimation(180, 0, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
                    animation.setDuration(durationMillis);
                    animation.setFillAfter(true);
                    item_expand_imageview.startAnimation(animation);
                }
                Animation animation = new Animation() {
                    protected void applyTransformation(float interpolatedTime, Transformation t) { //根据ImageView旋转动画的百分比来显示textview高度，达到动画效果
                        item_expand_textview.setHeight((int) (startValue + deltaValue * interpolatedTime));
                    }
                };
                animation.setDuration(durationMillis);
                item_expand_textview.startAnimation(animation);
            }
        });

        new Thread(new MynaturalsceneThread()).start();

    }
    //折叠文本内容
    public void init(){
        //设置文本
        item_expand_textview.setText(getText(R.string.scene));
        //descriptionView设置默认显示高度
        item_expand_textview.setHeight(item_expand_textview.getLineHeight() * maxDescripLine);
        //根据高度来判断是否需要再点击展开
        item_expand_textview.post(new Runnable() {

            @Override
            public void run() {
                item_expand_imageview.setVisibility(item_expand_textview.getLineCount() > maxDescripLine ? View.VISIBLE : View.GONE);
            }
        });
    }

    public void listdata(final List<Map<String, Object>> listData){
        // 2. 创建Adapter
        CustomAdapter adapter = new CustomAdapter(this, R.layout.activity_scene_listview, listData);
        // 3. 给ListView设置Adapter
        ListView listView = findViewById(R.id.lv_scene);
        listView.setAdapter(adapter);


        //点击每个listview跳到详情页
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent();
                intent.setClass(SceneActivity.this, ViewSpotActivity.class);
                Map<String, Object> map = listData.get((int) id);
                intent.putExtra("title", (String) map.get("title"));
                startActivityForResult(intent, 1);
            }
        });

    }



    //向ListView中填充数据
    public List<Map<String,Object>> getDataList(List<NaturalScene> naturalScenes) {

        List<Map<String, Object>> list = new ArrayList<>();
        Log.e("map", String.valueOf(naturalScenes.size()));

        for(int i = 0;i<naturalScenes.size();i++) {
            Map<String, Object> map1 = new HashMap<>();
            map1.put("title", naturalScenes.get(i).getScenetitle());
            map1.put("score", naturalScenes.get(i).getScenescore());
            map1.put("content", naturalScenes.get(i).getScenecontent());
            map1.put("image", naturalScenes.get(i).getSceneimage());
            map1.put("distance",naturalScenes.get(i).getScenedistance());
            map1.put("price", naturalScenes.get(i).getSceneprice());
            list.add(map1);
        }

        return list;
    }



    // 内部类 自定义Adapter类
    private class CustomAdapter extends BaseAdapter {
        private Context context;
        private int itemLayoutId;
        private List<Map<String, Object>> data;

        public CustomAdapter(Context context,   // 上下文环境
                             int itemLayoutId,  // item的View模板布局
                             List<Map<String, Object>> data) {  // 数据
            this.context = context;
            this.itemLayoutId = itemLayoutId;
            this.data = data;
        }

        // 返回数据个数
        @Override
        public int getCount() {
            return data.size();
        }

        // 根据ListView中Item的位置，返回Item对应数据
        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        // 根据ListView中Item位置，返回Item中对应数据ID
        @Override
        public long getItemId(int position) {
            return position;
        }

        // 根据位置，返回对应位置的Item的显示View
        @Override
        public View getView(int position,       // 位置
                            View convertView,   // 转换View
                            ViewGroup parent) { // 新生成的View的父容器



            if(convertView==null){
                // 从Activity的Context上下文环境中获取 布局填充器（根据布局文件创建相应对象）
                LayoutInflater inflater = LayoutInflater.from(context);
                // 使用布局填充器，根据构造函数中接收到的布局文件ID创建对应对象
                convertView = inflater.inflate(itemLayoutId, null);

                Log.e("111",position+"");
            }

            // 从viewNew（模板布局文件的跟元素类型 LinearLayout）中获取对应控件
            TextView textView1 = convertView.findViewById(R.id.scene_title);
            TextView textView2 = convertView.findViewById(R.id.scene_score);
            TextView textView3 = convertView.findViewById(R.id.scene_content);
            TextView textView4 = convertView.findViewById(R.id.scene_distance);
            TextView textView5 = convertView.findViewById(R.id.scene_price);
            ImageView imageView = convertView.findViewById(R.id.scene_image);
            // 根据Item位置，获取data（List）中对应位置的数据map
            Map<String, Object> map = data.get(position);
            // 从map中根据[键]找到对应的[值]，并设置到相应控件
            textView1.setText((String)map.get("title"));
            textView2.setText((String)map.get("score"));
            textView3.setText((String)map.get("content"));
            textView4.setText((String)map.get("distance"));
            textView5.setText((String)map.get("price"));
           // imageView.setImageResource((int)map.get("image"));
            String imag = (String)map.get("image");
            int imgid = getResources().getIdentifier(imag, "drawable","com.example.ll.project_main");
            imageView.setImageResource(imgid);
            // 返回创建好的View（已经设置完数据）
            return convertView;
        }
    }


    private class MynaturalsceneThread implements Runnable {
        @Override
        public void run() {
            final List<NaturalScene> naturalScenes = WebServiceNaturalScene.executeHttpNaturalscene();
            Log.e("huoqu", "ok" + naturalScenes.get(0));
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // 1. 获取数据
                    final List<Map<String, Object>> listData = getDataList(naturalScenes);
                    listdata(listData);
                }
            });
        }
    }
}

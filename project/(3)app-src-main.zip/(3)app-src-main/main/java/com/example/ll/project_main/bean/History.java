package com.example.ll.project_main.bean;

public class History {
    public int historyid;
    public String historytitle;
    public String historyscore;
    public String historycontent;
    public String historyimage;
    public String historydistance;
    public String historyprice;

    public int getHistoryid() {
        return historyid;
    }

    public void setHistoryid(int historyid) {
        this.historyid = historyid;
    }

    public String getHistorytitle() {
        return historytitle;
    }

    public void setHistorytitle(String historytitle) {
        this.historytitle = historytitle;
    }

    public String getHistoryscore() {
        return historyscore;
    }

    public void setHistoryscore(String historyscore) {
        this.historyscore = historyscore;
    }

    public String getHistorycontent() {
        return historycontent;
    }

    public void setHistorycontent(String historycontent) {
        this.historycontent = historycontent;
    }

    public String getHistoryimage() {
        return historyimage;
    }

    public void setHistoryimage(String historyimage) {
        this.historyimage = historyimage;
    }

    public String getHistorydistance() {
        return historydistance;
    }

    public void setHistorydistance(String historydistance) {
        this.historydistance = historydistance;
    }

    public String getHistoryprice() {
        return historyprice;
    }

    public void setHistoryprice(String historyprice) {
        this.historyprice = historyprice;
    }

    public History() {
    }

    public History(int historyid, String historytitle, String historyscore, String historycontent, String historyimage, String historydistance, String historyprice) {
        this.historyid = historyid;
        this.historytitle = historytitle;
        this.historyscore = historyscore;
        this.historycontent = historycontent;
        this.historyimage = historyimage;
        this.historydistance = historydistance;
        this.historyprice = historyprice;
    }
}

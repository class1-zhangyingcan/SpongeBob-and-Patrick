package com.example.ll.project_main.Utils;

public class CONSTS {
    public static final String HOST="http://10.7.88.207:8080/InTravel";
    public static final String City_Data_URL = HOST +"/api/city";

}

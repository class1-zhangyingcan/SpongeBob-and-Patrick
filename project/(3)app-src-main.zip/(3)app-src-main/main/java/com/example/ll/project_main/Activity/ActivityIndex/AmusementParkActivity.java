package com.example.ll.project_main.Activity.ActivityIndex;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.view.animation.Transformation;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.ll.project_main.R;
import com.example.ll.project_main.View.UnScrollListView;
import com.example.ll.project_main.bean.AmusePark;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AmusementParkActivity extends Activity {

//    private UnScrollListView amusementParkListView;
//    private AmusementParkAdapter amusementParkAdapter;
    //折叠部分（四行）
    private TextView item_expand_textview;
    private ImageView item_expand_imageview;
    private LinearLayout description_layout;
    int maxDescripLine = 2; //TextView默认最大展示行数
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.amusement_park );
        ImageView back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AmusementParkActivity.this.finish();
            }
        });
        //折叠部分（三行）
        item_expand_textview=findViewById(R.id.item_expand_textview);
        item_expand_imageview = findViewById(R.id.item_expand_imageview);
        description_layout = findViewById(R.id.description_layout);
        //折叠文本内容
        init();
        description_layout.setOnClickListener(new View.OnClickListener() {
            boolean isExpand;//是否已展开的状态

            @Override
            public void onClick(View v) {
                isExpand = !isExpand;
                item_expand_textview.clearAnimation();//清楚动画效果
                final int deltaValue;//默认高度，即前边由maxLine确定的高度
                final int startValue = item_expand_textview.getHeight();//起始高度
                int durationMillis = 350;//动画持续时间
                if (isExpand) {
                    /**
                     * 折叠动画
                     * 从实际高度缩回起始高度
                     */
                    deltaValue = item_expand_textview.getLineHeight() * item_expand_textview.getLineCount() - startValue;
                    RotateAnimation animation = new RotateAnimation(0, 180, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
                    animation.setDuration(durationMillis);
                    animation.setFillAfter(true);
                    item_expand_imageview.startAnimation(animation);
                } else {
                    /**
                     * 展开动画
                     * 从起始高度增长至实际高度
                     */
                    deltaValue = item_expand_textview.getLineHeight() * maxDescripLine - startValue;
                    RotateAnimation animation = new RotateAnimation(180, 0, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
                    animation.setDuration(durationMillis);
                    animation.setFillAfter(true);
                    item_expand_imageview.startAnimation(animation);
                }
                Animation animation = new Animation() {
                    protected void applyTransformation(float interpolatedTime, Transformation t) { //根据ImageView旋转动画的百分比来显示textview高度，达到动画效果
                        item_expand_textview.setHeight((int) (startValue + deltaValue * interpolatedTime));
                    }
                };
                animation.setDuration(durationMillis);
                item_expand_textview.startAnimation(animation);
            }
        });
        new Thread(new MyamusementThread()).start();
        MyScrollView myScrollView = findViewById(R.id.MyScrollView);

    }

    //折叠文本内容
    public void init(){
        //设置文本
        item_expand_textview.setText(getText(R.string.park));
        //descriptionView设置默认显示高度
        item_expand_textview.setHeight(item_expand_textview.getLineHeight() * maxDescripLine);
        //根据高度来判断是否需要再点击展开
        item_expand_textview.post(new Runnable() {

            @Override
            public void run() {
                item_expand_imageview.setVisibility(item_expand_textview.getLineCount() > maxDescripLine ? View.VISIBLE : View.GONE);
            }
        });
    }

    private void listdata(final List<Map<String, Object>> listData) {
//        amusementParkListView = findViewById( R.id.lv_amuse );
//        amusementParkAdapter =new AmusementParkAdapter(this,R.layout.amusement_park_listview,listData);
//        amusementParkListView.setAdapter( amusementParkAdapter );
//        amusementParkListView.setFocusable(false);
        // 2. 创建Adapter
        AmusementParkAdapter amusementParkAdapter = new AmusementParkAdapter(this, R.layout.amusement_park_listview, listData);
        // 3. 给ListView设置Adapter
        UnScrollListView amusementParkListView = findViewById(R.id.lv_amuse);
        amusementParkListView.setAdapter(amusementParkAdapter);
        amusementParkListView.setFocusable(false);

        //点击每个listview跳到详情页
        amusementParkListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent();
                intent.setClass(AmusementParkActivity.this, ViewParkActivity.class);
                Map<String, Object> map = listData.get((int) id);
                intent.putExtra("title1", (String) map.get("amusementParkTitle"));
                startActivityForResult(intent, 1);
            }
        });
    }


    public  class AmusementParkAdapter extends BaseAdapter{
        private Context context;
        private int itemId;
        private List<Map<String,Object>> list;

        public AmusementParkAdapter(Context context, int itemId, List<Map<String, Object>> list) {
            this.context = context;
            this.itemId= itemId;
            this.list = list;
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return list.get( position );
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(convertView==null){
                // 从Activity的Context上下文环境中获取 布局填充器（根据布局文件创建相应对象）
                LayoutInflater inflater = LayoutInflater.from(context);
                // 使用布局填充器，根据构造函数中接收到的布局文件ID创建对应对象
                convertView = inflater.inflate(itemId, null);

                Log.e("111",position+"");
            }

            // 从viewNew（模板布局文件的跟元素类型 LinearLayout）中获取对应控件
            ImageView amusementParkImage = convertView.findViewById( R.id.amuse_image );
            TextView amusementParkTitle =convertView.findViewById( R.id.amuse_title );
            TextView amusementParkScore = convertView.findViewById( R.id.amuse_score );
            TextView amusementParkContent = convertView.findViewById( R.id.amuse_content );
            TextView amusementParkDistance = convertView.findViewById( R.id.amuse_distance );
            TextView amusementParkPrice = convertView.findViewById( R.id.amuse_price );


            // 根据Item位置，获取data（List）中对应位置的数据map
            Map<String, Object> map = list.get(position);
            // 从map中根据[键]找到对应的[值]，并设置到相应控件
            amusementParkTitle.setText((String)map.get("amusementParkTitle"));
            amusementParkScore.setText((String)map.get("amusementParkScore"));
            amusementParkContent.setText((String)map.get("amusementParkContent"));
            amusementParkDistance.setText((String)map.get("amusementParkDistance"));
            amusementParkPrice.setText((String)map.get("amusementParkPrice"));
            String imag = (String)list.get( position ).get( "amusementParkImage" ) ;
            int imgid = getResources().getIdentifier(imag, "drawable","com.example.ll.project_main");
            amusementParkImage.setImageResource(imgid);


            // 返回创建好的View（已经设置完数据）
            return convertView;

        }
    }
    public List<Map<String,Object>> getList(List<AmusePark> amuseParks) {
        List<Map<String, Object>> list = new ArrayList<>();
        Log.e("11111", String.valueOf(amuseParks.size()));

        for(int i = 0;i<amuseParks.size();i++) {
            Map<String, Object> map1 = new HashMap<>();
            Log.e("sha", amuseParks.get(i).getAmusetitle());
//            map1.put("amusementParkImage", amuseParks.get(i).getAmuseimage());
//            map1.put("amusementParkTitle", amuseParks.get(i).getAmusetitle());
//            map1.put("amusementParkScore", amuseParks.get(i).getAmusescore());
//            map1.put("amusementParkContent", amuseParks.get(i).getAmusecontent());
//            map1.put("amusementParkDistance", amuseParks.get(i).getAmusedistance());
//            map1.put("amusementParkPrice",amuseParks.get(i).getAmuseprice());

            map1.put("amusementParkImage", R.drawable.amusementpark2);
            map1.put("amusementParkTitle", "dddd");
            map1.put("amusementParkScore", "ddsgfgf");
            map1.put("amusementParkContent", "dfgh");
            map1.put("amusementParkDistance", "sdfghj");
            map1.put("amusementParkPrice","sdfghjk");
        }

        return list;
    }

    private class MyamusementThread implements Runnable {
        @Override
        public void run() {
            final List<AmusePark> amuseParks = WebServiceAmuse.executeHttpAmuse();
            Log.e("huoqu", "ok" + amuseParks.get(0));
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // 1. 获取数据
                    final List<Map<String, Object>> listData = getList(amuseParks);
                    listdata(listData);
                }
            });
        }
    }
}
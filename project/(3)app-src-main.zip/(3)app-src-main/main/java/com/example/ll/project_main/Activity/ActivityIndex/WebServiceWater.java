package com.example.ll.project_main.Activity.ActivityIndex;

import android.util.Log;

import com.example.ll.project_main.bean.FoodCulture;
import com.example.ll.project_main.bean.WaterPark;
import com.example.ll.project_main.Utils.Url;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class WebServiceWater {
    private static List<WaterPark> waterParks = new ArrayList<>();

    protected static List<WaterPark> executeHttpWater() {

        try {
            URL Url = new URL(com.example.ll.project_main.Utils.Url.getUrl()+"WaterParkLet");

            HttpURLConnection connection = (HttpURLConnection) Url.openConnection();
//            connection.setDoOutput(true);
//            connection.setRequestMethod("GET");
            Log.e("chenggong","11");
            connection.setRequestProperty("contentType","UTF-8");   //解决中文字符乱码
            InputStream in = connection.getInputStream();   //字节流
            Log.e("chenggong","22");

            //字节流转字符流
            InputStreamReader inputStreamReader = new InputStreamReader(in);   //转换流
            BufferedReader reader = new BufferedReader(inputStreamReader);     //得到字符流
            String str = reader.readLine();
            Log.e("chenggong", String.valueOf(str.length()));

            //解析JSONArray字符串
            JSONArray array = new JSONArray(str);
            Log.e("length", String.valueOf(array.length()));
            for(int i = 0;i<array.length();i++){
                JSONObject object = array.getJSONObject(i);
                WaterPark waterPark = new WaterPark();
                waterPark.setWatertitle(object.getString("waterparktitle"));
                waterPark.setWaterscore(object.getString("waterparkscore"));
                waterPark.setWatercontent(object.getString("waterparkcontent"));
                waterPark.setWaterimage(object.getString("waterparkimage"));
                waterPark.setWaterdistance(object.getString("waterparkdistance"));
                waterPark.setWaterprice(object.getString("waterparkprice"));
                Log.e("chenggong", waterPark.getWatercontent());


                waterParks.add(waterPark);
            }
            Log.e("SceneList",waterParks.toString());
            Log.e("SceneList",str);
        } catch (MalformedURLException e) {
            Log.e("test", e.toString());
            e.printStackTrace();
        } catch (IOException e) {
            Log.e("test", e.toString());
            e.printStackTrace();
        } catch (JSONException e) {
            Log.e("test", e.toString());
            e.printStackTrace();
        }

        return waterParks;
    }
}

package com.example.ll.project_main.Activity.ActivityIndex;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ll.project_main.R;
import com.example.ll.project_main.bean.NaturalScene;

import java.util.List;

public class NewsAdapter extends BaseAdapter {
    private List<NaturalScene> mList;
    private LayoutInflater mInflater;

    public NewsAdapter(Context context, List<NaturalScene> data){
        mList = data;
        mInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public Object getItem(int arg0) {
        return mList.get(arg0);
    }

    @Override
    public long getItemId(int arg0) {
        return arg0;
    }



    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if(convertView == null){
            viewHolder = new ViewHolder();
            convertView = mInflater.inflate( R.layout.scenelistview, null);


            viewHolder.textView1 = convertView.findViewById(R.id.naturalscene_title);
            viewHolder.textView2 = convertView.findViewById(R.id.naturalscene_score);
            viewHolder.textView3 = convertView.findViewById(R.id.naturalscene_content);
            viewHolder.textView4 = convertView.findViewById(R.id.naturalscene_distance);
            viewHolder.textView5 = convertView.findViewById(R.id.naturalscene_price);

            viewHolder.imageView = convertView.findViewById(R.id.iv_image);
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.imageView.setImageResource(Integer.parseInt(mList.get(position).sceneimage));	// default picture
        viewHolder.textView1.setText(mList.get(position).scenetitle);
        viewHolder.textView2.setText(mList.get(position).scenescore);
        viewHolder.textView3.setText(mList.get(position).scenecontent);
        viewHolder.textView4.setText(mList.get(position).scenedistance);
        viewHolder.textView5.setText(mList.get(position).sceneprice);
        return convertView;
    }

    /*
     * 用文艺式
     * */
    class ViewHolder{

        public TextView textView1;
        public TextView textView2;
        public TextView textView3;
        public TextView textView4;
        public TextView textView5;
        public ImageView imageView;


    }


}

package com.example.ll.project_main.Utils;

public class Url {
    public static String url;

    public static String getUrl() {
        url = "http://192.168.43.9:8080/InTravel/";
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}

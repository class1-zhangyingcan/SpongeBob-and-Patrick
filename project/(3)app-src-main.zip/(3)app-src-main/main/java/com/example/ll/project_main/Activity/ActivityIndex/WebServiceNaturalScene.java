package com.example.ll.project_main.Activity.ActivityIndex;

import android.util.Log;

import com.example.ll.project_main.bean.NaturalScene;
import com.example.ll.project_main.Utils.Url;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class WebServiceNaturalScene {
    private static List<NaturalScene> naturalscenes = new ArrayList<>();

    protected static List<NaturalScene> executeHttpNaturalscene() {
        Url url1 = null;

        try {
            URL Url = new URL(com.example.ll.project_main.Utils.Url.getUrl()+"NaturalSceneLet");

            HttpURLConnection connection = (HttpURLConnection) Url.openConnection();
//            connection.setDoOutput(true);
//            connection.setRequestMethod("GET");
            Log.e("chenggong","11");
            connection.setRequestProperty("contentType","UTF-8");   //解决中文字符乱码
            InputStream in = connection.getInputStream();   //字节流
            Log.e("chenggong","22");

            //字节流转字符流
            InputStreamReader inputStreamReader = new InputStreamReader(in);   //转换流
            BufferedReader reader = new BufferedReader(inputStreamReader);     //得到字符流
            String str = reader.readLine();
            Log.e("chenggong", String.valueOf(str.length()));

            //解析JSONArray字符串
            JSONArray array = new JSONArray(str);
            Log.e("length", String.valueOf(array.length()));
            for(int i = 0;i<array.length();i++){
                JSONObject object = array.getJSONObject(i);
                NaturalScene naturalScene = new NaturalScene();
                naturalScene.setScenetitle(object.getString("naturalscenetitle"));
                naturalScene.setScenescore(object.getString("naturalscenescore"));
                naturalScene.setScenecontent(object.getString("naturalscenecontent"));
                naturalScene.setSceneimage(object.getString("naturalsceneimage"));
                naturalScene.setScenedistance(object.getString("naturalscenedistance"));
                naturalScene.setSceneprice(object.getString("naturalsceneprice"));
                Log.e("chenggong",naturalScene.getScenedistance());

                naturalscenes.add(naturalScene);
            }
            Log.e("SceneList1", "11"+naturalscenes.size());
            Log.e("SceneList",str);
        } catch (MalformedURLException e) {
            Log.e("test", e.toString());
            e.printStackTrace();
        } catch (IOException e) {
            Log.e("test", e.toString());
            e.printStackTrace();
        } catch (JSONException e) {
            Log.e("test", e.toString());
            e.printStackTrace();
        }

        return naturalscenes;
    }
}

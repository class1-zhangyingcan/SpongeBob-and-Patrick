package com.example.ll.project_main.bean;

public class MineBean {
    private int UserId;
    private String UserName;
    private String UserMark;
    private String UserSex;
    private String UserEmail;
    private String UserPsw;
    private String UserPhone;
    private String UserImage;

    public int getUserId() {
        return UserId;
    }

    public void setUserId(int userId) {
        UserId = userId;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public String getUserMark() {
        return UserMark;
    }

    public void setUserMark(String userMark) {
        UserMark = userMark;
    }

    public String getUserSex() {
        return UserSex;
    }

    public void setUserSex(String userSex) {
        UserSex = userSex;
    }

    public String getUserEmail() {
        return UserEmail;
    }

    public void setUserEmail(String userEmail) {
        UserEmail = userEmail;
    }

    public String getUserPsw() {
        return UserPsw;
    }

    public void setUserPsw(String userPsw) {
        UserPsw = userPsw;
    }

    public String getUserPhone() {
        return UserPhone;
    }

    public void setUserPhone(String userPhone) {
        UserPhone = userPhone;
    }

    public String getUserImage() {
        return UserImage;
    }

    public void setUserImage(String userImage) {
        UserImage = userImage;
    }
}

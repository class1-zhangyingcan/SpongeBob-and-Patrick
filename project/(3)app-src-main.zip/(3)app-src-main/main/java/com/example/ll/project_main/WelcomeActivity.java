package com.example.ll.project_main;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.example.ll.project_main.Utils.SharedUtils;

import java.util.Timer;
import java.util.TimerTask;

//延时跳转可以使用handler
public class WelcomeActivity extends AppCompatActivity{
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);
        /*new Handler(new Handler.Callback() {
            //处理接收到的消息的方法
            @Override
            public boolean handleMessage(Message msg) {
                //实现页面跳转
                startActivity(new Intent(getApplicationContext(),WelcomeGuideActivity.class));
                return false;
            }
        }).sendEmptyMessageDelayed(0,3000);   //表示延时三秒进行任务的执行*/
        //使用Java中的定时器进行处理
        Timer timer = new Timer();
        timer.schedule(new Task(),3000);  //定时器延时执行任务的方法
    }
    class Task extends TimerTask{

        @Override
        public void run() {
             //实现页面跳转
            //不是第一次启动
           /* if(SharedUtils.getWelcomeBoolean(getBaseContext())){
                startActivity(new Intent(getBaseContext(),Login.class));
            }else {
                startActivity(new Intent(WelcomeActivity.this,WelcomeGuideActivity.class));
                //保存访问记录
                SharedUtils.putWelcomeBoolean(getBaseContext(),true);
            }*/
            //finish();
            startActivity(new Intent(WelcomeActivity.this,WelcomeGuideActivity.class));
            finish();

        }
    }

}

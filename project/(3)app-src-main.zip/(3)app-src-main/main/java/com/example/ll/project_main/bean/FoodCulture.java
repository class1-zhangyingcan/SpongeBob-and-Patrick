package com.example.ll.project_main.bean;

public class FoodCulture {
    public int foodcultureid;
    public String foodculturetitle;
    public String foodculturescore;
    public String foodculturecontent;
    public String foodcultureimage;
    public String foodculturedistance;
    public String foodcultureprice;

    public int getFoodcultureid() {
        return foodcultureid;
    }

    public void setFoodcultureid(int foodcultureid) {
        this.foodcultureid = foodcultureid;
    }

    public String getFoodculturetitle() {
        return foodculturetitle;
    }

    public void setFoodculturetitle(String foodculturetitle) {
        this.foodculturetitle = foodculturetitle;
    }

    public String getFoodculturescore() {
        return foodculturescore;
    }

    public void setFoodculturescore(String foodculturescore) {
        this.foodculturescore = foodculturescore;
    }

    public String getFoodculturecontent() {
        return foodculturecontent;
    }

    public void setFoodculturecontent(String foodculturecontent) {
        this.foodculturecontent = foodculturecontent;
    }

    public String getFoodcultureimage() {
        return foodcultureimage;
    }

    public void setFoodcultureimage(String foodcultureimage) {
        this.foodcultureimage = foodcultureimage;
    }

    public String getFoodculturedistance() {
        return foodculturedistance;
    }

    public void setFoodculturedistance(String foodculturedistance) {
        this.foodculturedistance = foodculturedistance;
    }

    public String getFoodcultureprice() {
        return foodcultureprice;
    }

    public void setFoodcultureprice(String foodcultureprice) {
        this.foodcultureprice = foodcultureprice;
    }

    public FoodCulture() {
    }

    public FoodCulture(int foodcultureid, String foodculturetitle, String foodculturescore, String foodculturecontent, String foodcultureimage, String foodculturedistance, String foodcultureprice) {
        this.foodcultureid = foodcultureid;
        this.foodculturetitle = foodculturetitle;
        this.foodculturescore = foodculturescore;
        this.foodculturecontent = foodculturecontent;
        this.foodcultureimage = foodcultureimage;
        this.foodculturedistance = foodculturedistance;
        this.foodcultureprice = foodcultureprice;
    }
}

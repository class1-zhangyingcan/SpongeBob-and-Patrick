package com.example.ll.project_main;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;;
import android.widget.ImageView;
import android.widget.ListView;

import android.widget.TextView;

import com.example.ll.project_main.bean.MineBean;
import com.example.ll.project_main.bean.UserBean;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HeadActivity extends Activity {
    //修改内容
    private List<Map<String,Object>> dataList;
    private ListView listView;
    MyAdapter adapter;
    //更换头像：头像名称+弹窗+标识值
    private static final String IMAGE_FILE_NAME = "faceImage.jpg";
    private String[] items =new String[] { "选择本地照片", "拍照" };
    protected static final int CHOOSE_PICTURE = 0;
    protected static final int TAKE_PICTURE = 1;
    private static final int CROP_SMALL_PICTURE = 2;
    private MineBean ps;
    private Handler handler;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.head_layout);
        //显示手机号
        Intent intent = getIntent();
        String messageNew = intent.getStringExtra("phone");
        TextView textView =findViewById(R.id.tv_phone);
        textView.setText( messageNew );
        if(messageNew!=null){
            String number=messageNew.substring(0,3)+"****"+messageNew.substring(7,messageNew.length());
            textView.setText(number);
        }

        new Thread(new MineThread()).start();

        new Thread(new MyThread()).start();

        //解决7.0系统打开sd卡找不到文件的问题(相机重启问题）
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
            StrictMode.setVmPolicy(builder.build());
        }

      //注销账号监听器
        Button  btn_out=findViewById(R.id.btn_out);
        btn_out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(HeadActivity.this, Login.class);
                startActivity(intent);
            }
        });

     //头像点击监听器
        ImageView mImage=findViewById(R.id.h_head);
        mImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showChoosePicDialog();
            }
        });
        //返回到mainActivity
        Button btnBack = findViewById( R.id.btn_back_main);
        btnBack.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity( new Intent( HeadActivity.this,MainActivity.class ) );
            }
        } );
    }

    // 显示更换图片的对话框
    protected void showChoosePicDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(HeadActivity.this);
        builder.setTitle("设置头像");
        builder.setItems(items, new DialogInterface.OnClickListener() {
            @Override
        public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0: // 选择本地照片
                        Intent intentFromGallery = new Intent();
                        intentFromGallery.setType("image/*");
                        intentFromGallery.setAction(Intent.ACTION_GET_CONTENT);
                        //用startActivityForResult方法，待会儿重写onActivityResult()方法，拿到图片做裁剪操作
                        startActivityForResult(intentFromGallery, CHOOSE_PICTURE);
                        break;
                    case 1: // 拍照
                        Intent intentFromCapture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE); ;
                        intentFromCapture.putExtra(MediaStore.EXTRA_OUTPUT,
                                Uri.fromFile(new File(Environment.getExternalStorageDirectory(),IMAGE_FILE_NAME)));
                        startActivityForResult(intentFromCapture, TAKE_PICTURE);
                        break;
                }
            }
        })
        .setNegativeButton("取消", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        }).show();
    }

   // 重写onActivityResult方法
    public void onActivityResult(int requestCode, int resultCode,@Nullable Intent data) {
       // Log.e("MainActivity","RequestCode:"+requestCode+"ResultCode:"+resultCode);
        if (resultCode==2){
            final String text2=data.getStringExtra("text2New");
            int id=data.getIntExtra("id",0);
            Map<String,Object> map=new HashMap<>();
            map.put("image1",dataList.get(id).get("image1"));
            map.put("text1",dataList.get(id).get("text1"));
            map.put("text2",text2);
            dataList.set(id,map);
            listView.setAdapter(adapter);
           super.onActivityResult(requestCode,resultCode,data);

        }else{
           super.onActivityResult(requestCode,resultCode,data);
        }
        //头像
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case TAKE_PICTURE:
                    File tempFile = new File(Environment.getExternalStorageDirectory(),IMAGE_FILE_NAME);
                    cutImage(Uri.fromFile(tempFile)); // 对图片进行裁剪处理
                    break;
                case CHOOSE_PICTURE:
                    cutImage(data.getData()); // 对图片进行裁剪处理

                    break;
                case CROP_SMALL_PICTURE:
                    if (data != null) {
                        setImageToView(data); // 让刚才选择裁剪得到的图片显示在界面上
                        setBlurBackground(data);
                    }
                    break;

            }
        }
      super.onActivityResult(requestCode,resultCode,data);
    }

   //裁剪图片方法实现
    protected void cutImage(Uri uri) {
        if (uri == null) {
            Log.i("tag", "The uri is not exist.");
        }
        Intent intent = new Intent("com.android.camera.action.CROP");
        //com.android.camera.action.CROP这个action是用来裁剪图片用的
        intent.setDataAndType(uri, "image/*");
        // 设置裁剪
        intent.putExtra("crop", "true");
        // aspectX aspectY 是宽高的比例
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        // outputX outputY 是裁剪图片宽高
        intent.putExtra("outputX", 320);
        intent.putExtra("outputY", 320);
        intent.putExtra("return-data", true);
        startActivityForResult(intent, 2);

    }

    //保存裁剪之后的图片数据
    private void setImageToView(Intent data) {
        Bundle extras = data.getExtras();
        if (extras != null) {
            Bitmap photo= extras.getParcelable("data");
            ImageView mImage=findViewById(R.id.h_head);
            mImage.setImageBitmap(photo);//显示图片
//             sendImage(photo);
        }
    }

//    private void sendImage(Bitmap photo) {
//        Log.e("转换图片","zhuanhuan");
//        ByteArrayOutputStream picture = new ByteArrayOutputStream();//将Bitmap转成Byte[]
//        photo.compress(Bitmap.CompressFormat.PNG, 50, picture);//压缩
//        String headpicture = Base64.encodeToString(picture.toByteArray(), Base64.DEFAULT);//加密转换成String
//        new Thread(new SubmitThread(headpicture)).start();
//    }


    //设置毛玻璃背景 背景图片 Bitmap
    private void setBlurBackground(Intent data)  {
    Bundle extras = data.getExtras();
        if (extras != null) {
        Bitmap bphoto= extras.getParcelable("data");
        final Bitmap blurBmp = BlurUtil.fastblur(HeadActivity.this, bphoto, 10);//0-25，表示模糊值
        final Drawable drawable = ImageUtil.getDrawable(this,blurBmp);//将bitmap类型图片 转为 Drawable类型
        final ImageView vImage=findViewById(R.id.h_back);
        vImage.post(new Runnable() //调用UI线程
        {
            @Override
            public void run()
            {
                vImage.setBackgroundDrawable(drawable);
            }
        });
    }
}

    private void initListView() {
        adapter = new MyAdapter(this, R.layout.listview_item, dataList);
        listView = findViewById(R.id.lv_test);
        listView.addFooterView(new ViewStub(getApplicationContext()));
        listView.setAdapter(adapter);
        //4.绑定监听器
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent=new Intent();
                intent.setClass(HeadActivity.this,UpdateMainActivity.class);
                Map<String,Object> map=dataList.get((int)id);
                intent.putExtra("image1",(int)map.get("image1"));
                intent.putExtra("text1",(String)map.get("text1"));
                intent.putExtra("text2",(String)map.get("text2"));
                intent.putExtra("id",(int)id);


                Intent intent1=getIntent();
                intent.putExtra("phone1",intent1.getStringExtra( "phone" ));
                Log.e("HeadActivityId1",String.valueOf(id));
                startActivityForResult(intent,1);


            }
        });
    }

    //内部类 自定义Adapter类
    private class MyAdapter extends BaseAdapter {

        private Context context;
        private int itemLayoutId;
        private List<Map<String, Object>> datalist;

        public MyAdapter(Context context,//上下文环境
                             int itemLayoutId,//item的View模板布局
                             List<Map<String, Object>> datalist) { //数据
            this.context = context;
            this.itemLayoutId = itemLayoutId;
            this.datalist = datalist;
        }
        @Override
        public int getCount() {
            return dataList.size();
        }

        @Override
        public Object getItem(int position) {
            return dataList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position,
                            View convertView,
                            ViewGroup parent) {
            if (convertView == null) {
                //从Activity的Context上下文环境中获取 布局填充器（根据布局文件创建相应对象）
                LayoutInflater inflater = LayoutInflater.from(context);
                //使用布局填充器，根据构造函数中接收到的布局文件ID创建对应对象
                convertView = inflater.inflate(itemLayoutId, null);
            }
            TextView text1 = convertView.findViewById(R.id.my_text1);
            TextView text2 = convertView.findViewById(R.id.my_text2);
            ImageView image1 = convertView.findViewById(R.id.my_image);
            //根据Item位置，获取data（List）中对应位置的数据Map
            Map<String, Object> map = dataList.get(position);
            text1.setText((String) map.get("text1"));
            text2.setText((String) map.get("text2"));
            image1.setImageResource((int) map.get("image1"));
            return convertView;
        }

    }
    private void getDataList(MineBean ps){
        int[] image1s={R.drawable.email1,R.drawable.mark1,R.drawable.sex1};
        int[] image2s={R.drawable.icon,R.drawable.icon,R.drawable.icon};
        String[] text1s={"邮箱","个性签名","性别"};

        Log.e("laile",ps.getUserEmail());
        String[] text2s={ps.getUserEmail(),ps.getUserMark(),ps.getUserSex()};

        dataList=new ArrayList<Map<String, Object>>();
        for(int i=0;i<3;i++){
            Map<String,Object> map=new HashMap<>();
            map.put("image1",image1s[i]);
            map.put("image2",image2s[i]);
            map.put("text1",text1s[i]);
            map.put("text2",text2s[i]);
            dataList.add(map);
        }
        initListView();
    }


    private class MineThread implements Runnable {
        @Override
        public void run() {
            Intent intent=getIntent();
            final UserBean newuser=WebServiceUser.executeHttpPost(intent.getStringExtra("phone"));

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    initView(newuser);

                }
            });
        }
    }

    private void initView(UserBean newuser) {
        TextView tvname=findViewById(R.id.tv_name);
        TextView tvpsw=findViewById(R.id.tv_psw);
        if(newuser.getUserPsw()!=null){
            tvpsw.setText(newuser.getUserPsw());
            tvpsw.setTransformationMethod(PasswordTransformationMethod.getInstance());
        }
        tvname.setText(newuser.getUserName());
    }
    public void finish() {
        moveTaskToBack(true); //设置该activity永不过期，即不执行onDestroy()
    }

    private class MyThread implements Runnable {
        @Override
        public void run() {
            Intent intent = getIntent();
            final MineBean ps=WebServicePs.executeHttpPost(intent.getStringExtra("phone"));
            //Log.e("hhh", ps.getUserEmail());


            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    getDataList(ps);

                }
            });
        }
    }
}
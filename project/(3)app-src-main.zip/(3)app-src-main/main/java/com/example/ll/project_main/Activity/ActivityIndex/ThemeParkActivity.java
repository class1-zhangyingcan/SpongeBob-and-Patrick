package com.example.ll.project_main.Activity.ActivityIndex;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ll.project_main.R;
import com.example.ll.project_main.View.UnScrollListView;
import com.example.ll.project_main.bean.ThemePark;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ThemeParkActivity extends Activity implements View.OnClickListener{

    private MyScrollView myScrollView;
    private UnScrollListView themeParkListView;
    private ThemeParkAdapter themeParkAdpater;
    //悬浮按钮
    private FloatingActionButton topBtn;
    private int scrollY = 0;// 标记上次滑动位置
    private View contentView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_theme_park );
        myScrollView = findViewById(R.id.MyScrollView);
        new Thread(new MythemeparkThread()).start();


        //左上水世界
        TextView waterworld = (TextView) findViewById(R.id.tv_riverworld);
        waterworld.getBackground().setAlpha(200);
        //右上游乐场
        TextView park = findViewById(R.id.tv_play);
        park.getBackground().setAlpha(200);
        //点击左上跳转到水世界页面
        waterworld.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(ThemeParkActivity.this, WaterParkActivity.class);
                startActivity(intent);
            }
        });
        //点击右上跳到游乐场页面
        park.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(ThemeParkActivity.this, AmusementParkActivity.class);
                startActivity(intent);
            }
        });

        //悬浮按钮方法
        initView();
    }

    //关于悬浮按钮
    //初始化视图
    @SuppressLint("ClickableViewAccessibility")
    private void initView() {
        myScrollView = findViewById(R.id.MyScrollView);
        if (contentView == null) {
            contentView = myScrollView.getChildAt(0);
        }
        topBtn = (FloatingActionButton) findViewById(R.id.btn_floating_top);
        topBtn.setOnClickListener(this);
        //监听ScrollView滑动停止
        myScrollView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    handler.sendMessageDelayed(
                            handler.obtainMessage(touchEventId, v), 5);
                }
                return false;
            }
            private int lastY = 0;
            private int touchEventId = -9983761;
            Handler handler = new Handler() {
                @Override
                public void handleMessage(Message msg) {
                    super.handleMessage(msg);
                    View scroller = (View) msg.obj;
                    if (msg.what == touchEventId) {
                        if (lastY == scroller.getScrollY()) {
                            handleStop(scroller);
                        } else {
                            handler.sendMessageDelayed(handler.obtainMessage(
                                    touchEventId, scroller), 5);
                            lastY = scroller.getScrollY();
                        }
                    }
                }
            };
            private void handleStop(Object view) {


                MyScrollView scroller = (MyScrollView) view;
                scrollY = scroller.getScrollY();

                doOnBorderListener();
            }
        });
    }
    @SuppressLint("RestrictedApi")
    private void doOnBorderListener() {
        // 底部判断
        if (contentView != null
                && contentView.getMeasuredHeight() <= myScrollView.getScrollY()
                + myScrollView.getHeight()) {
            topBtn.setVisibility(View.VISIBLE);
        }
        // 顶部判断
        else if (myScrollView.getScrollY() == 0) {

        } else if (myScrollView.getScrollY() > 30) {
            topBtn.setVisibility(View.VISIBLE);
        }
    }
    @SuppressLint("RestrictedApi")
    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        switch (v.getId()) {
            case R.id.btn_floating_top:
                myScrollView.post(new Runnable() {
                    @Override
                    public void run() {
                        myScrollView.fullScroll(MyScrollView.FOCUS_UP);
                    }
                });
                topBtn.setVisibility(View.GONE);
                break;
        }
    }

    private class MythemeparkThread implements Runnable {
        @Override
        public void run() {
            final List<ThemePark> themeParks = WebServiceTheme.executeHttpTheme();
            Log.e("huoqu", "ok" + themeParks.get(0));
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // 1. 获取数据
                    final List<Map<String, Object>> listData = getList(themeParks);
                    listdata(listData);
                }
            });

        }
    }
    public void listdata(final List<Map<String, Object>> listData){
        themeParkListView = findViewById( R.id.lv_test );
        themeParkListView.setFocusable(false);
        themeParkAdpater = new ThemeParkAdapter(this,R.layout.activity_theme_park_listview,listData);
        themeParkListView.setAdapter( themeParkAdpater );

        //点击每个listview跳到详情页
        themeParkListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent();
                intent.setClass(ThemeParkActivity.this, ViewParkActivity.class);
                Map<String, Object> map = listData.get((int) id);
                intent.putExtra("title1", (String) map.get("themeParkTitle"));
                startActivityForResult(intent, 1);
            }
        });

    }
    public class ThemeParkAdapter extends BaseAdapter {
        private Context context;
        private int itemId;
        private List<Map<String,Object>> list;

        public ThemeParkAdapter(Context context, int itemId, List<Map<String, Object>> list) {
            this.context = context;
            this.itemId = itemId;
            this.list = list;
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return list.get( position );
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView==null){
                LayoutInflater inflater = LayoutInflater.from(context);
                convertView = inflater.inflate( itemId,null );
            }
            ImageView themeParkImage = convertView.findViewById( R.id.park_image );
            TextView themeParkTitle =convertView.findViewById( R.id.park_title );
            TextView themeParkScore = convertView.findViewById( R.id.park_score );
            TextView themeParkContent = convertView.findViewById( R.id.park_content );
            TextView themeParkDistance = convertView.findViewById( R.id.park_distance );
            TextView themeParkPrice = convertView.findViewById( R.id.park_price );
            // themeParkImage.setImageResource( (int) list.get( position ).get( "themeParkImage" ) );
            String imag = (String)list.get( position ).get( "themeParkImage" ) ;
            int imgid = getResources().getIdentifier(imag, "drawable","com.example.ll.project_main");
            themeParkImage.setImageResource(imgid);
            themeParkTitle.setText( (String) list.get( position ).get( "themeParkTitle" ) );
            themeParkScore.setText( (String)list.get( position ).get( "themeParkScore" ) );
            themeParkContent.setText( (String)list.get(position ).get( "themeParkContent" ) );
            themeParkDistance.setText( (String)list.get( position).get( "themeParkDistance" ) );
            themeParkPrice.setText( (String)list.get( position ).get( "themeParkPrice" ) );
            return convertView;
        }
    }
    public List<Map<String,Object>> getList(List<ThemePark> themeParks){
        List<Map<String,Object>> list = new ArrayList<>(  );

        for(int i = 0;i<themeParks.size();i++) {
            Map<String, Object> map1 = new HashMap<>();
            map1.put("themeParkImage", themeParks.get(i).getThemeparkimage());
            map1.put("themeParkTitle", themeParks.get(i).getThemeparktitle());
            map1.put("themeParkScore",  themeParks.get(i).getThemeparkscore());
            map1.put("themeParkContent", themeParks.get(i).getThemeparkcontent());
            map1.put("themeParkDistance", themeParks.get(i).getThemeparkdistance());
            map1.put("themeParkPrice",  themeParks.get(i).getThemeparkprice());
            list.add(map1);
        }
        return  list;
    }
}

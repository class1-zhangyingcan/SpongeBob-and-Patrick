package com.example.ll.project_main.Activity.ActivityIndex;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.view.animation.Transformation;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.ll.project_main.R;
import com.example.ll.project_main.View.UnScrollListView;
import com.example.ll.project_main.bean.WaterPark;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WaterParkActivity extends Activity {
    private MyScrollView myScrollView;
    private UnScrollListView waterParkListView;
    private WaterParkAdapter waterParkAdapter;
    //折叠部分（四行）
    private TextView item_expand_textview;
    private ImageView item_expand_imageview;
    private LinearLayout description_layout;
    int maxDescripLine = 2; //TextView默认最大展示行数


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_water );
        ImageView back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WaterParkActivity.this.finish();
            }
        });
        myScrollView = findViewById(R.id.MyScrollView);

        new Thread(new MywaterparkThread()).start();


        //折叠部分（三行）
        item_expand_textview=findViewById(R.id.item_expand_textview);
        item_expand_imageview = findViewById(R.id.item_expand_imageview);
        description_layout = findViewById(R.id.description_layout);
        //折叠文本内容
        init();
        description_layout.setOnClickListener(new View.OnClickListener() {
            boolean isExpand;//是否已展开的状态

            @Override
            public void onClick(View v) {
                isExpand = !isExpand;
                item_expand_textview.clearAnimation();//清楚动画效果
                final int deltaValue;//默认高度，即前边由maxLine确定的高度
                final int startValue = item_expand_textview.getHeight();//起始高度
                int durationMillis = 350;//动画持续时间
                if (isExpand) {
                    /**
                     * 折叠动画
                     * 从实际高度缩回起始高度
                     */
                    deltaValue = item_expand_textview.getLineHeight() * item_expand_textview.getLineCount() - startValue;
                    RotateAnimation animation = new RotateAnimation(0, 180, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
                    animation.setDuration(durationMillis);
                    animation.setFillAfter(true);
                    item_expand_imageview.startAnimation(animation);
                } else {
                    /**
                     * 展开动画
                     * 从起始高度增长至实际高度
                     */
                    deltaValue = item_expand_textview.getLineHeight() * maxDescripLine - startValue;
                    RotateAnimation animation = new RotateAnimation(180, 0, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
                    animation.setDuration(durationMillis);
                    animation.setFillAfter(true);
                    item_expand_imageview.startAnimation(animation);
                }
                Animation animation = new Animation() {
                    protected void applyTransformation(float interpolatedTime, Transformation t) { //根据ImageView旋转动画的百分比来显示textview高度，达到动画效果
                        item_expand_textview.setHeight((int) (startValue + deltaValue * interpolatedTime));
                    }
                };
                animation.setDuration(durationMillis);
                item_expand_textview.startAnimation(animation);
            }
        });
    }

    //折叠文本内容
    public void init(){
        //设置文本
        item_expand_textview.setText(getText(R.string.water));
        //descriptionView设置默认显示高度
        item_expand_textview.setHeight(item_expand_textview.getLineHeight() * maxDescripLine);
        //根据高度来判断是否需要再点击展开
        item_expand_textview.post(new Runnable() {

            @Override
            public void run() {
                item_expand_imageview.setVisibility(item_expand_textview.getLineCount() > maxDescripLine ? View.VISIBLE : View.GONE);
            }
        });
    }

    public class WaterParkAdapter extends BaseAdapter {
        private Context context;
        private int itemId;
        private List<Map<String, Object>> list;

        public WaterParkAdapter(Context context, int itemId, List<Map<String, Object>> list) {
            this.context = context;
            this.itemId = itemId;
            this.list = list;
        }

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return list.get( position );
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater inflater = LayoutInflater.from( context );
                convertView = inflater.inflate( itemId, null );
            }
            ImageView waterParkImage = convertView.findViewById( R.id.water_image );
            TextView waterParkTitle = convertView.findViewById( R.id.water_title );
            TextView waterParkScore = convertView.findViewById( R.id.water_score );
            TextView waterParkContent = convertView.findViewById( R.id.water_content );
            TextView waterParkDistance = convertView.findViewById( R.id.water_distance );
            TextView waterParkPrice = convertView.findViewById( R.id.water_price );

            String imag = (String)list.get( position ).get( "waterParkImage" ) ;
            int imgid = getResources().getIdentifier(imag, "drawable","com.example.ll.project_main");
            waterParkImage.setImageResource(imgid);
            waterParkTitle.setText( (String) list.get( position ).get( "waterParkTitle" ) );
            waterParkScore.setText( (String) list.get( position ).get( "waterParkScore" ) );
            waterParkContent.setText( (String) list.get( position ).get( "waterParkContent" ) );
            waterParkDistance.setText( (String) list.get( position ).get( "waterParkDistance" ) );
            waterParkPrice.setText( (String) list.get( position ).get( "waterParkPrice" ) );
            return convertView;
        }
    }

    public List<Map<String, Object>> getList(List<WaterPark> waterParks) {
        List<Map<String, Object>> list = new ArrayList<>();

        for(int i = 0;i<waterParks.size();i++) {
            Map<String, Object> map1 = new HashMap<>();
            map1.put("waterParkImage", waterParks.get(i).getWaterimage());
            map1.put("waterParkTitle", waterParks.get(i).getWatertitle());
            map1.put("waterParkScore",waterParks.get(i).getWaterscore());
            map1.put("waterParkContent", waterParks.get(i).getWatercontent());
            map1.put("waterParkDistance",waterParks.get(i).getWaterdistance());
            map1.put("waterParkPrice",waterParks.get(i).getWaterprice());

            list.add(map1);
        }
        return list;
    }

    private class MywaterparkThread implements Runnable {
        @Override
        public void run() {
            final List<WaterPark> waterParks = WebServiceWater.executeHttpWater();
            Log.e("huoqu", "ok" + waterParks.get(0));
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    // 1. 获取数据
                    final List<Map<String, Object>> listData = getList(waterParks);
                    listdata(listData);
                }
            });
        }
    }

    private void listdata(final List<Map<String, Object>> listData) {
        waterParkListView = findViewById( R.id.lv_history );
        waterParkAdapter = new WaterParkAdapter( this, R.layout.activity_water_listview, listData);
        waterParkListView.setAdapter( waterParkAdapter );
        waterParkListView.setFocusable(false);
        //点击每个listview跳到详情页
        waterParkListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent();
                intent.setClass(WaterParkActivity.this, ViewParkActivity.class);
                Map<String, Object> map = listData.get((int) id);
                intent.putExtra("title1", (String) map.get("waterParkTitle"));
                startActivityForResult(intent, 1);
            }
        });
    }
}
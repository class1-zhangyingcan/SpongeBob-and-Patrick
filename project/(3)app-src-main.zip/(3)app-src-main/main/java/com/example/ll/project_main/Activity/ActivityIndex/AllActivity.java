package com.example.ll.project_main.Activity.ActivityIndex;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.example.ll.project_main.R;

public class AllActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.allactivity);
        //自然景观一跳转
        Button btn1 = findViewById( R.id.yi);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(AllActivity.this, NaturalSceneActivity.class);
                startActivity(intent);
            }
        });
        //自然景观二跳转
        Button btn2 = findViewById(R.id.er);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(AllActivity.this, SceneActivity.class);
                startActivity(intent);
            }
        });

        //人文历史一跳转
        Button btn3 = findViewById(R.id.san);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(AllActivity.this, HumanityActivity.class);
                startActivity(intent);
            }
        });
        //人文历史二跳转
        Button btn4 = findViewById(R.id.si);
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(AllActivity.this, HistoryActivity.class);
                startActivity(intent);
            }
        });

        //主题乐园一跳转
        Button btn5 = findViewById(R.id.wu);
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(AllActivity.this, ThemeParkActivity.class);
                startActivity(intent);
            }
        });
        //游乐场跳转
        Button btn6 = findViewById(R.id.liu);
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(AllActivity.this, AmusementParkActivity.class);
                startActivity(intent);
            }
        });

        //美食文化一跳转
        Button btn7 = findViewById(R.id.qi);
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(AllActivity.this, FoodcultureActivity.class);
                startActivity(intent);
            }
        });
        //美食文化二跳转
        Button btn8 = findViewById(R.id.ba);
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(AllActivity.this, FoodActivity.class);
                startActivity(intent);
            }
        });
        //水世界跳转
        Button btn9 = findViewById(R.id.jiu);
        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(AllActivity.this, WaterParkActivity.class);
                startActivity(intent);
            }
        });
    }

}

package com.example.ll.project_main.Activity.ActivityIndex;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ll.project_main.R;
import com.example.ll.project_main.bean.FoodBean;

import java.util.ArrayList;
import java.util.List;


public class ViewFoodActivity extends AppCompatActivity{
    private ViewPager pager;
    private List<View> list;
    private List<FoodBean> foods = new ArrayList<>();
    private TextView T;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( R.layout.viewfood);

        Intent intent = getIntent();
        T=(TextView)findViewById(R.id.food_title);
        T.setText(intent.getStringExtra("title2"));

        new Thread(new MySceneThread()).start();


        pager = findViewById(R.id.food_image);

    }

    protected void insert(FoodBean food){
        TextView foodcontent = findViewById(R.id.food_content);
        TextView foodscore = findViewById(R.id.food_score);
        TextView foodaddress = findViewById(R.id.food_address);
        TextView foodtime = findViewById(R.id.food_time);
        TextView foodlist = findViewById(R.id.food_list);
        TextView fooddish = findViewById(R.id.food_dish);
        foodcontent.setText(food.getFoodcontent());
        foodscore.setText(food.getFoodscore());
        foodaddress.setText(food.getFoodaddress());
        foodtime.setText(food.getFoodtime());
        foodlist.setText(food.getFoodlist());
        fooddish.setText(food.getFooddish());
    }



    //初始化View Pager的方法
    public void initViewPager(FoodBean food) {

        ApplicationInfo appInfo = getApplicationInfo();

        list = new ArrayList<View>();
        ImageView iv1 = new ImageView(this);
        iv1.setScaleType(ImageView.ScaleType.FIT_XY);
        String imag1 = food.getFoodimagesrc1();
        Log.e("tupian",imag1);
//        int resID1 = getResources().getIdentifier(imag1,"drawable",appInfo.packageName);
//        Bitmap image1 = BitmapFactory.decodeResource(getResources(),resID1);
//        iv1.setImageBitmap(image1);
        int imgid1 = getResources().getIdentifier(imag1, "drawable","com.example.ll.project_main");
        iv1.setBackgroundResource(imgid1);
        list.add(iv1);

        ImageView iv2 = new ImageView(this);
        iv2.setScaleType(ImageView.ScaleType.FIT_XY);
        String imag2 = food.getFoodimagesrc2();
        int imgid2 = getResources().getIdentifier(imag2, "drawable","com.example.ll.project_main");
        iv2.setBackgroundResource(imgid2);
//        int resID2 = getResources().getIdentifier(imag2,"drawable",appInfo.packageName);
//        Bitmap image2 = BitmapFactory.decodeResource(getResources(),resID2);
//        iv2.setImageBitmap(image2);
        list.add(iv2);

        ImageView iv3 = new ImageView(this);
        iv3.setScaleType(ImageView.ScaleType.FIT_XY);
        String imag3 = food.getFoodimagesrc3();
        int imgid3 = getResources().getIdentifier(imag3, "drawable","com.example.ll.project_main");
        iv3.setBackgroundResource(imgid3);
//        int resID3 = getResources().getIdentifier(imag3,"drawable",appInfo.packageName);
//        Bitmap image3 = BitmapFactory.decodeResource(getResources(),resID3);
//        iv3.setImageBitmap(image3);
        list.add(iv3);

        pager.setAdapter(new MyPagerAdapter());
        //监听ViewPager滑动效果
        pager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {

            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });

    }



    //定义ViewPager的适配器
    class MyPagerAdapter extends PagerAdapter {
        //计算需要多少item显示
        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
            return view==o;
        }
        //初始化item实例方法
        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            container.addView(list.get(position)) ;
            return list.get(position);
        }
        //item销毁的方法
        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {

            // super.destroyItem(container, position, object);
            container.removeView(list.get(position));
        }
    }


    private class MySceneThread implements Runnable {
        @Override
        public void run() {
            Intent intent = getIntent();
            final FoodBean newfood =  ViewFood.executeHttpPost(intent.getStringExtra("title2"));
            Log.e("hahaha",newfood.getFoodaddress());

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    initViewPager(newfood);
                    insert(newfood);
                }
            });
        }
    }
}

package com.example.ll.project_main;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.mob.MobSDK;

import java.util.Map;

import com.example.ll.project_main.R;
import cn.smssdk.EventHandler;
import cn.smssdk.SMSSDK;

public class InputphoneActivity extends AppCompatActivity{
    //立刻验证按钮
    private Button btngetcode;
    private CountTimer countTimer;
    //手机号文本框
    private EditText etphone;
    //验证码文本框
    private EditText edit_cord;
    private String cord_number;
    EventHandler eventHandler;
    private boolean flag = true;
    private String phone_number;
    //下一步按钮
    private Button next;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.input_phone);
        countTimer = new CountTimer(60000,1000);
        //手机号文本框
        etphone = findViewById(R.id.et_phone);
        phone_number = etphone.getText().toString().trim();
        //获取验证码按钮
        btngetcode = findViewById(R.id.btn_getcode);
        //点击了获取验证码按钮，开始计时
        btngetcode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                countTimer.start();

                if(judPhone())//去掉左右空格获取字符串
                {
                    SMSSDK.getVerificationCode("86",phone_number);
                    edit_cord.requestFocus();
                }

            }
        });
        //验证码文本框
        edit_cord = findViewById(R.id.edit_code);
        //下一步按钮
        next = findViewById(R.id.next);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //SMSSDK.submitVerificationCode( "86", phone_number, cord_number );
                if(judCord()) {
                    SMSSDK.submitVerificationCode( "86", phone_number, cord_number );
                    flag = false;
                    Intent intent = new Intent();
                    intent.setClass( InputphoneActivity.this, NextPasswordActivity.class );

                    intent.putExtra( "phone", phone_number );
                    startActivityForResult( intent, 1 );
                }else{
                    Toast.makeText(InputphoneActivity.this,"错了，再来一遍",Toast.LENGTH_LONG).show();
                    //Intent intent
                }
            }
        });


        //短信验证码
        MobSDK.init(this,"28f3d3389db6c","425d81d5ac53c59f01640ef8c6905a4c");
        eventHandler = new EventHandler() {
            public void afterEvent(int event, int result, Object data) {
                Message msg = new Message();
                msg.arg1 = event;
                msg.arg2 = result;
                msg.obj = data;
                handler.sendMessage(msg);
            }
        };

        SMSSDK.registerEventHandler(eventHandler);

    }
    //每隔一分钟，可点击一次验证码
    public class CountTimer extends CountDownTimer{

        /**
         * @param millisInFuture    The number of millis in the future from the call
         *   //时间间隔是多长时间                      to {@link #start()} until the countdown is done and {@link #onFinish()}
         *                          is called.
         * @param countDownInterval The interval along the way to receive
         *   回调onTick方法，多长时间执行一次                   {@link #onTick(long)} callbacks.
         */
        public CountTimer(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }
        //间隔时间内执行的操作
        @Override
        public void onTick(long millisUntilFinished) {
            //更新页面组件
            btngetcode.setText(millisUntilFinished/1000+"后重新发送");
            btngetcode.setBackgroundResource(R.drawable.btn_press);
            btngetcode.setClickable(false);

        }
        //间隔时间结束的时候调用
        @Override
        public void onFinish() {
            //更新页面组件
            btngetcode.setText(R.string.register_get_check_num);
            //btngetcode.setBackgroundResource();
            btngetcode.setClickable(true);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SMSSDK.unregisterEventHandler(eventHandler);
    }

    /**
     * 使用Handler来分发Message对象到主线程中，处理事件
     */
    Handler handler=new Handler()
    {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            int event=msg.arg1;
            int result=msg.arg2;
            Object data=msg.obj;
           /* if (event == SMSSDK.EVENT_GET_VERIFICATION_CODE) {
                if(result == SMSSDK.RESULT_COMPLETE) {
                    boolean smart = (Boolean)data;
                    if(smart) {
                      *//*  Toast.makeText(getApplicationContext(),"该手机号已经注册过，请重新输入",
                                Toast.LENGTH_LONG).show();
                        etphone.requestFocus();*//*
                        return;
                    }
                }
            }*/
            if(result==SMSSDK.RESULT_COMPLETE)
            {

                if (event == SMSSDK.EVENT_SUBMIT_VERIFICATION_CODE) {
                    Toast.makeText(getApplicationContext(), "验证成功",
                            Toast.LENGTH_LONG).show();
                }
            }
            else
            {
                if(flag)
                {
                    btngetcode.setVisibility(View.VISIBLE);
                    Toast.makeText(getApplicationContext(),"验证码获取失败请重新获取", Toast.LENGTH_LONG).show();
                    etphone.requestFocus();
                }
                else
                {
                    Toast.makeText(getApplicationContext(),"验证码输入错误", Toast.LENGTH_LONG).show();
                }
            }

        }

    };

    private boolean judPhone()
    {
        if(TextUtils.isEmpty(etphone.getText().toString().trim()))
        {
            Toast.makeText(InputphoneActivity.this,"请输入您的电话号码",Toast.LENGTH_LONG).show();
            etphone.requestFocus();
            return false;
        }
        else if(etphone.getText().toString().trim().length()!=11)
        {
            Toast.makeText(InputphoneActivity.this,"您的电话号码位数不正确",Toast.LENGTH_LONG).show();
            etphone.requestFocus();
            return false;
        }
        else
        {
            phone_number=etphone.getText().toString().trim();
            String num="[1][358]\\d{9}";
            if(phone_number.matches(num))
                return true;
            else
            {
                Toast.makeText(InputphoneActivity.this,"请输入正确的手机号码",Toast.LENGTH_LONG).show();
                return false;
            }
        }
    }

    private boolean judCord()
    {
        judPhone();
        if(TextUtils.isEmpty(edit_cord.getText().toString().trim()))
        {
            Toast.makeText(InputphoneActivity.this,"请输入您的验证码",Toast.LENGTH_LONG).show();
            edit_cord.requestFocus();
            return false;
        }
        else if(edit_cord.getText().toString().trim().length()!=4)
        {
            Toast.makeText(InputphoneActivity.this,"您的验证码位数不正确",Toast.LENGTH_LONG).show();
            edit_cord.requestFocus();

            return false;
        }
        else
        {
            cord_number=edit_cord.getText().toString().trim();
            return true;
        }

    }









}

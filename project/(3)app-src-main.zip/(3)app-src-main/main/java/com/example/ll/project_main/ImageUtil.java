package com.example.ll.project_main;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

public class ImageUtil{
    public static Drawable getDrawable(Context context, Bitmap bm){
        BitmapDrawable bd= new BitmapDrawable(context.getResources(),bm);
        return bd;
    }
}
package com.example.ll.project_main.Utils;

import com.example.ll.project_main.R;

public class LlUtils {
   // new public WebServiceInteractGet();
   // WebServiceInteractGet.executeHttpInteract()


    //返回值
    public static final int RequestInteractCode = 2;
    public static final int praiseNumber = 5;
    public static String[] userNameSort={"小铭","小红","路飞","山治","娜美"};
    public static String[] interactTimeSort={"2017年8月21日5点4分","2007年8月21日5点4分"
    ,"2017年9月21日5点4分","2017年10月21日5点4分","2017年11月21日5点4分"};
    public static String[] interactSort = {"哈哈哈1","去打四皇","赏金1个亿","我是路飞","我想吃肉"};

    public static int[] userPhotoSort ={R.drawable.usertouxiang100,R.drawable.usertouxiang101,
            R.drawable.usertoxiang103,R.drawable.touxiang104,R.drawable.touxiang105};
    public static int[] interactPhoto = {R.drawable.interactphoto100,R.drawable.interactphoto101,
    R.drawable.interactphoto102,R.drawable.interactphoto103,R.drawable.interactphoto104};
}

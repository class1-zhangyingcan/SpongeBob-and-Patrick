package com.example.ll.project_main.Utils;

public class UrlContent {
    public static String urlIp = "http://192.168.43.9:8080/InTravel";
}
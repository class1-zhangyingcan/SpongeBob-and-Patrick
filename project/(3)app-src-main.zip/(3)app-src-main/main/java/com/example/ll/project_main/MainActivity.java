package com.example.ll.project_main;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.os.Bundle;
import android.util.Log;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;

public class MainActivity extends FragmentActivity
        implements RadioGroup.OnCheckedChangeListener {
    @ViewInject(R.id.main_bottom_tabs)
    private RadioGroup group;
    @ViewInject(R.id.main_home)
    private RadioButton main_home;
    private FragmentManager fragmentManager;//管理fragment

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
        ViewUtils.inject( this );
        //初始化FragmentManager
        fragmentManager = getSupportFragmentManager();
        //设置默认选中
        main_home.setChecked( true );
        group.setOnCheckedChangeListener( this );
        //切换不同的fragment
        changeFragment( new HomeIndex(), false );
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        switch (checkedId) {
            case R.id.main_home:
                changeFragment( new HomeIndex(), true );
                break;
            case R.id.main_plan:
                changeFragment( new HomePlan(), true );
                break;
            case R.id.main_find:
                changeFragment( new HomeFind(), true );
                break;
            case R.id.main_my:
                changeFragment( new HomeMy(), true );
                break;
            default:
                break;
        }

    }

    //切换不同fragment
    public void changeFragment(Fragment fragment, boolean isInit) {
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace( R.id.main_content, fragment );
        if (!isInit == false) {
            transaction.commit();
        }
    }

//    Intent intent = getIntent();
//    String messageNew = intent.getStringExtra( "phone" );
//
//    Fragment myFragment = new Fragment();
//    Bundle bundle = new Bundle();


}


package com.example.ll.project_main.Activity.indexActivity;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

public class HumanityActivity extends Activity{
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        Log.e( "xxxx","你归来" );
    }
}

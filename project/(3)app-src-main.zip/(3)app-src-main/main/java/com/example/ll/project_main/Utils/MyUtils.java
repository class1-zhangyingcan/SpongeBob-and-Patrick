package com.example.ll.project_main.Utils;

public class MyUtils {
    public static final int RequestCityCode = 2;
}

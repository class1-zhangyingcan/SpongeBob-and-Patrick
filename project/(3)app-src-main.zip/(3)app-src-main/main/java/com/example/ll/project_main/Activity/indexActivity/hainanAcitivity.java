package com.example.ll.project_main.Activity.indexActivity;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;

public class hainanAcitivity extends Activity{
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        Log.e( "hhhh","你归来" );
    }
}

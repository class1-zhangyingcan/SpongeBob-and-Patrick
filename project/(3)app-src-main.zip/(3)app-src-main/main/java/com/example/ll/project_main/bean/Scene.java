package com.example.ll.project_main.bean;

public class Scene {
    private int sceneid;
    private String sceneimagesrc1;
    private String sceneimagesrc2;
    private String sceneimagesrc3;
    private String scenename;
    private String scenerank;
    private String scenedistance;
    private String scenelocation;
    private String sceneopentime;
    private String sceneplaytime;
    private double scenemark;

    public String getScenename() {
        return scenename;
    }

    public void setScenename(String scenename) {
        this.scenename = scenename;
    }

    public int getSceneid() {
        return sceneid;
    }

    public void setSceneid(int sceneid) {
        this.sceneid = sceneid;
    }

    public String getSceneimagesrc1() {
        return sceneimagesrc1;
    }

    public void setSceneimagesrc1(String sceneimagesrc1) {
        this.sceneimagesrc1 = sceneimagesrc1;
    }

    public String getSceneimagesrc2() {
        return sceneimagesrc2;
    }

    public void setSceneimagesrc2(String sceneimagesrc2) {
        this.sceneimagesrc2 = sceneimagesrc2;
    }

    public String getSceneimagesrc3() {
        return sceneimagesrc3;
    }

    public void setSceneimagesrc3(String sceneimagesrc3) {
        this.sceneimagesrc3 = sceneimagesrc3;
    }

    public String getScenerank() {
        return scenerank;
    }

    public void setScenerank(String scenerank) {
        this.scenerank = scenerank;
    }

    public String getScenedistance() {
        return scenedistance;
    }

    public void setScenedistance(String scenedistance) {
        this.scenedistance = scenedistance;
    }

    public String getScenelocation() {
        return scenelocation;
    }

    public void setScenelocation(String scenelocation) {
        this.scenelocation = scenelocation;
    }

    public String getSceneopentime() {
        return sceneopentime;
    }

    public void setSceneopentime(String sceneopentime) {
        this.sceneopentime = sceneopentime;
    }

    public String getSceneplaytime() {
        return sceneplaytime;
    }

    public void setSceneplaytime(String sceneplaytime) {
        this.sceneplaytime = sceneplaytime;
    }

    public double getScenemark() {
        return scenemark;
    }

    public void setScenemark(double scenemark) {
        this.scenemark = scenemark;
    }
}

package com.example.ll.project_main;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.ll.project_main.R;
import com.example.ll.project_main.WebServiceForget;
public class NextPasswordActivity extends AppCompatActivity{
    private EditText newpsw;
    private String newpassword;
    private Button sure;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nextpassword);
        //密码文本框
        newpsw = findViewById(R.id.newpsw);
        //确定按钮
        sure = findViewById(R.id.sure);
        //用户输入新密码，点击确定按钮后，将数据库中的旧密码改成新密码，弹出修改成功，返回登录页面
        sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new MypswThread()).start();
                Toast.makeText(NextPasswordActivity.this, "修改成功 请重新登录", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent();
                intent.setClass(NextPasswordActivity.this,Login.class);
                startActivity(intent);
            }
        });
    }
    private class MypswThread implements Runnable {
        @Override
        public void run() {
            newpassword = newpsw.getText().toString();
            Intent intent = getIntent();
            final String change =  WebServiceForget.executeHttpForget(intent.getStringExtra("phone"),newpassword);
        }
    }
}

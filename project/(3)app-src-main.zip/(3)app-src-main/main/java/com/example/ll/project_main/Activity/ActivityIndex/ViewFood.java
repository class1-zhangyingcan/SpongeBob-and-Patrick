package com.example.ll.project_main.Activity.ActivityIndex;

import android.support.annotation.Nullable;
import android.util.Log;

import com.example.ll.project_main.bean.FoodBean;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;




public class ViewFood {
    @Nullable
    public static FoodBean executeHttpPost(String foodtitle) {
        FoodBean food = new FoodBean();
        try {
            URL url = new URL(com.example.ll.project_main.Utils.Url.getUrl()+"FoodTitle?foodtitle="+foodtitle);
            Log.d("22","333");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestProperty("contentType", "UTF-8");


            InputStream in = connection.getInputStream();
            Log.e("jinlaile","333");


            //字节流转字符流
            InputStreamReader inputStreamReader = new InputStreamReader(in);
            BufferedReader reader = new BufferedReader(inputStreamReader);
            String str = reader.readLine();

            //解析JSONArray字符串
            JSONArray array = new JSONArray(str);

            //      for (int i = 0; i < array.length(); i++) {

            JSONObject object = array.getJSONObject(0);
            Log.e( "ceshi",object.getString( "foodtitle" ) );
            food.setFoodimagesrc1(object.getString("foodimagesrc1"));
            food.setFoodimagesrc2(object.getString("foodimagesrc2"));
            food.setFoodimagesrc3(object.getString("foodimagesrc3"));
            food.setFoodtitle(object.getString("foodtitle"));
            food.setFoodcontent(object.getString("foodcontent"));
            food.setFoodscore(object.getString("foodscore"));
            food.setFoodaddress(object.getString("foodaddress"));
            food.setFoodtime(object.getString("foodtime"));
            food.setFoodlist(object.getString("foodlist"));
            food.setFooddish(object.getString("fooddish"));
            //   scenes.add(scene);
            //    }
            Log.e("Scene", food.getFoodimagesrc2());
            Log.e("Scene", str);
            return food;


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }
}

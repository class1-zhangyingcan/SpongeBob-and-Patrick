package com.example.ll.project_main;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;

//import com.example.ll.project_main.Adapter.CustomAdapter1;
import com.example.ll.project_main.Activity.ActivityIndex.FoodActivity;
import com.example.ll.project_main.Activity.ActivityIndex.FoodcultureActivity;
import com.example.ll.project_main.Activity.ActivityIndex.NaturalSceneActivity;
import com.example.ll.project_main.Activity.indexActivity.HumanityActivity;
import com.example.ll.project_main.Activity.indexActivity.NaturalLandscape;
import com.example.ll.project_main.Activity.ActivityIndex.ThemeParkActivity;
import com.example.ll.project_main.bean.NaturalScene;
import com.lidroid.xutils.view.annotation.ViewInject;


public class HomeIndex extends Fragment{
    @ViewInject( R.id.list1 )
    private ListView listViewFirst1;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate( R.layout.activity_home_index, null );
        //ViewUtils.inject( this,view );
        //findData(view);
        //listViewFirst1.setAdapter( new CustomAdapter1() );
        return view;
    }


//    @ViewInject( R.id.iv_visit )
//    private ImageView naturalLandscapeImg;


//@OnClick( {R.id.iv_visit} )
//public void OnClick(View v){
//    switch (v.getId()) {
//        case R.id.iv_visit:
//            Intent intent1 = new Intent( getActivity(), NaturalLandscape.class);
//            startActivity( intent1 );
//            break;
//        case R.id.iv_history:
//            Intent intent2=new Intent(getActivity(), HumanityActivity.class);
//            startActivity(intent2);
//            break;
//        case R.id.iv_tree:
//            Intent intent3=new Intent(getActivity(), ThemeParkActivity.class);
//            startActivity(intent3);
//        case R.id.iv_food:
//            Intent intent4=new Intent(getActivity(), FoodcultureActivity.class);
//            startActivity(intent4);
//            break;
//        case R.id.iv_chengdu:
//            Intent intent5=new Intent(getActivity(), chengduActivity.class);
//            startActivity(intent5);
//            break;
//        case R.id.iv_hainan:
//            Intent intent6 = new Intent(getActivity(), hainanAcitivity.class);
//            startActivity(intent6);
//            break;
//        case R.id.iv_neimeng:
//            Intent intent7 = new Intent(getActivity(), neimengActivity.class);
//            startActivity(intent7);
//            break;
//        case R.id.iv_arl1:
//            Intent intent8 = new Intent(getActivity(), arl1Activity.class);
//            startActivity(intent8);
//            break;
//        case R.id.iv_arl2:
//            Intent intent9 = new Intent(getActivity(), arl2Activity.class);
//            startActivity(intent9);
//            break;
//        case R.id.iv_arl3:
//            Intent intent10 = new Intent(getActivity(), arl3Activity.class);
//            startActivity(intent10);
//            break;
//        case R.id.iv_arl4:
//            Intent intent11 = new Intent(getActivity(), arl4Activity.class);
//            startActivity(intent11);
//            break;
//        case R.id.iv_arl5:
//            Intent intent12 = new Intent(getActivity(), arl5Activity.class);
//            startActivity(intent12);
//            break;
//        case R.id.iv_like1:
//            Intent intent13 = new Intent(getActivity(), like1Activity.class);
//            startActivity(intent13);
//            break;
//        case R.id.iv_like2:
//            Intent intent14 = new Intent(getActivity(), like2Activity.class);
//            startActivity(intent14);
//            break;
//        case R.id.iv_like3:
//            Intent intent15 = new Intent(getActivity(), like3Activity.class);
//            startActivity(intent15);
//            break;
//        case R.id.iv_like4:
//            Intent intent16 = new Intent(getActivity(), like4Activity.class);
//            startActivity(intent16);
//            break;
//
//
//    }
//


//    private void findData(View view){
//       ListView indexView1 =view.findViewById( R.id.list1 );
//    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        //private ListView listfirst=null;
        super.onActivityCreated( savedInstanceState );
        ImageView ivVisit = getView().findViewById( R.id.iv_visit );
        ivVisit.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(  );
                intent.setClass( getActivity(),NaturalSceneActivity.class );
                startActivity( intent );
            }
        } );

        ImageView ivHistory = getView().findViewById( R.id.iv_history );
        ivHistory.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(  );
                intent.setClass( getActivity(), com.example.ll.project_main.Activity.ActivityIndex.HumanityActivity.class );
                startActivity( intent );
            }
        } );

        //主题乐园
        ImageView ivTree = getView().findViewById( R.id.iv_tree );
        ivTree.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity( new Intent( getActivity(),ThemeParkActivity.class ));
            }
        } );
                ImageView ivFood = getView().findViewById( R.id.iv_food );
                ivFood.setOnClickListener( new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity( new Intent( getActivity(),FoodcultureActivity.class ) );
                    }
                } );

    }
}



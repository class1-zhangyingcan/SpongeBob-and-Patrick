package com.example.ll.project_main;

import android.util.Log;

import com.example.ll.project_main.Utils.UrlContent;
import com.example.ll.project_main.bean.MineBean;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class WebServiceMail {
    public static Boolean executeHttpPost(String email,String phone) {
        MineBean mineBean = new MineBean();
        try {
            String urlIp = UrlContent.urlIp;
            URL url = new URL(urlIp+"/MineMail?email="+email+"&phone="+phone);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestProperty("contentType", "UTF-8");


            InputStream in = connection.getInputStream();
            Log.e("执行到这里了","eee");


            //字节流转字符流
            InputStreamReader inputStreamReader = new InputStreamReader(in);
            BufferedReader reader = new BufferedReader(inputStreamReader);
            String str = reader.readLine();

            //解析JSONArray字符串
            JSONArray array = new JSONArray(str);
            JSONObject object = array.getJSONObject(0);
            mineBean.setUserEmail(object.getString("useremail"));
            mineBean.setUserPhone(object.getString("userphone"));
            return true;


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return false;
    }
}

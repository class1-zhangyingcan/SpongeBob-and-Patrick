package com.example.ll.project_main.Activity.ActivityIndex;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.ll.project_main.R;
import com.example.ll.project_main.Utils.MyUtils;
import com.example.ll.project_main.Utils.SharedUtils;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;

import java.io.IOException;
import java.util.List;

public class HomeActivity extends Activity implements LocationListener{

    //@ViewInject(R.id.index_top_city)
    private TextView topCity;
    private String cityName;  //当前城市名称
    private LocationManager locationManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( R.layout.activity_home_index);
        //ViewUtils.inject(this);
        //获取数据并且显示
        topCity = findViewById(R.id.tv_1);
        // topCity.setText(SharedUtils.getCityName(this));
//        topCity.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent();
//                intent.setClass(HomeActivity.this,CityActivity.class);
//                startActivity(intent);
//            }
//        });
    }


//    @OnClick({R.id.index_top_city})
//    public void onClick(View v){
//        switch(v.getId()){
//            case R.id.index_top_city:
//                startActivityForResult(new Intent(this,CityActivity.class), MyUtils.RequestCityCode);
//                break;
//            default:
//                break;
//        }
//    }
    //处理返回值的结果
    public void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==MyUtils.RequestCityCode && resultCode == Activity.RESULT_OK){
            cityName = data.getStringExtra("cityName");
            topCity.setText(cityName);
        }
    }



    @Override
    public void onStart() {
        super.onStart();
        //检查当前GPS模块
        checkGPSIsOpen();
    }
    //检查是否打开GPS
    private void checkGPSIsOpen(){
        //获取当前LocationManager对象
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        boolean isOpen = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        if(!isOpen){
            //进入GPS设置页面
            Intent intent = new Intent();
            intent.setAction(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivityForResult(intent,0);

        }
        //打开之后，开始定位
        startLocation();
    }
    //使用GPS定位的方法
    @SuppressLint("MissingPermission")
    private void startLocation(){
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,2000,10,this);

    }

    //接受并且处理消息
    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            if(msg.what==1){
                topCity.setText(cityName);
            }
            return false;
        }
    });


    //位置信息更改执行的方法
    @Override
    public void onLocationChanged(Location location) {
        //更新当前位置信息
        updateWithNewLocation(location);
    }
    //获取对应位置的经纬度，并且定位城市
    private void updateWithNewLocation(Location location) {
        double lat =0.0,lng = 0.0;
        if(location!=null){
            lat = location.getLatitude();
            lng = location.getLongitude();

        }else {
            cityName = "无法获取城市信息";
        }
        //通过经纬度来获取地址，由于地址会有多个，这个和精确度有关
        List<Address> list = null;
        Geocoder ge = new Geocoder(this);
        try {
            list = ge.getFromLocation(lat,lng,2);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(list!=null && list.size()>0){
            for(int i=0;i<list.size();i++){
                Address ad = list.get(i);
                cityName = ad.getLocality(); //获取城市
            }

        }
        //发送空消息
        handler. sendEmptyMessage(1);
    }




    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        //保存城市
        SharedUtils.putCityName(this,cityName);
        //停止定位
        stopLocation();

    }
    //停止定位
    private void stopLocation(){
//     locationManager.removeUpdates(this);
    }

}

package com.example.ll.project_main.bean;

public class ParkBean {
    private int parkid;
    private String parkimagesrc1;
    private String parkimagesrc2;
    private String parkimagesrc3;
    private String parkname;
    private String parkcontent;
    private String parkscore;
    private String parkdistance;
    private String parklocation;
    private String parkopentime;

    public int getParkid() {
        return parkid;
    }

    public void setParkid(int parkid) {
        this.parkid = parkid;
    }

    public String getParkimagesrc1() {
        return parkimagesrc1;
    }

    public void setParkimagesrc1(String parkimagesrc1) {
        this.parkimagesrc1 = parkimagesrc1;
    }

    public String getParkimagesrc2() {
        return parkimagesrc2;
    }

    public void setParkimagesrc2(String parkimagesrc2) {
        this.parkimagesrc2 = parkimagesrc2;
    }

    public String getParkimagesrc3() {
        return parkimagesrc3;
    }

    public void setParkimagesrc3(String parkimagesrc3) {
        this.parkimagesrc3 = parkimagesrc3;
    }

    public String getParkname() {
        return parkname;
    }

    public void setParkname(String parkname) {
        this.parkname = parkname;
    }

    public String getParkcontent() {
        return parkcontent;
    }

    public void setParkcontent(String parkcontent) {
        this.parkcontent = parkcontent;
    }

    public String getParkscore() {
        return parkscore;
    }

    public void setParkscore(String parkscore) {
        this.parkscore = parkscore;
    }

    public String getParkdistance() {
        return parkdistance;
    }

    public void setParkdistance(String parkdistance) {
        this.parkdistance = parkdistance;
    }

    public String getParklocation() {
        return parklocation;
    }

    public void setParklocation(String parklocation) {
        this.parklocation = parklocation;
    }

    public String getParkopentime() {
        return parkopentime;
    }

    public void setParkopentime(String parkopentime) {
        this.parkopentime = parkopentime;
    }
}

package com.example.ll.project_main.Activity.ActivityIndex;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ll.project_main.R;
import com.example.ll.project_main.bean.ParkBean;

import java.util.ArrayList;
import java.util.List;


public class ViewParkActivity extends AppCompatActivity{
    private MyScrollView myScrollView;
    private ViewPager pager;
    private List<View> list;
    private List<ParkBean> parks = new ArrayList<>();
    private TextView T;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( R.layout.viewpark);
        myScrollView = findViewById(R.id.MyScrollView);
        Intent intent = getIntent();
        T=(TextView)findViewById(R.id.park_title);
        T.setText(intent.getStringExtra("title1"));

        new Thread(new MySceneThread()).start();


        pager = findViewById(R.id.park_image);
    }

    protected void insert(ParkBean park){
        TextView parktitle = findViewById(R.id.park_title);
        TextView parkcontnt = findViewById(R.id.park_content);
        TextView parkscore = findViewById(R.id.park_score);
        TextView parkopentime = findViewById(R.id.park_open_time);
        TextView parkdistance = findViewById(R.id.park_distance);
        TextView parklocation = findViewById(R.id.park_location);
        parktitle.setText(park.getParkname());
        parkcontnt.setText(park.getParkcontent());
        parkscore.setText(park.getParkscore());
        parkopentime.setText(park.getParkopentime());
        parkdistance.setText(park.getParkdistance());
        parklocation.setText(park.getParklocation());
    }



    //初始化View Pager的方法
    public void initViewPager(ParkBean park) {

        ApplicationInfo appInfo = getApplicationInfo();

        list = new ArrayList<View>();
        ImageView iv1 = new ImageView(this);
        iv1.setScaleType(ImageView.ScaleType.FIT_XY);
        String imag1 = park.getParkimagesrc1();
        Log.e("tupian",imag1);
//        int resID1 = getResources().getIdentifier(imag1,"drawable",appInfo.packageName);
//        Bitmap image1 = BitmapFactory.decodeResource(getResources(),resID1);
//        iv1.setImageBitmap(image1);
        int imgid1 = getResources().getIdentifier(imag1, "drawable","com.example.ll.project_main");
        iv1.setBackgroundResource(imgid1);
        list.add(iv1);

        ImageView iv2 = new ImageView(this);
        iv2.setScaleType(ImageView.ScaleType.FIT_XY);
        String imag2 = park.getParkimagesrc2();
        int imgid2 = getResources().getIdentifier(imag2, "drawable","com.example.ll.project_main");
        iv2.setBackgroundResource(imgid2);
//        int resID2 = getResources().getIdentifier(imag2,"drawable",appInfo.packageName);
//        Bitmap image2 = BitmapFactory.decodeResource(getResources(),resID2);
//        iv2.setImageBitmap(image2);
        list.add(iv2);

        ImageView iv3 = new ImageView(this);
        iv3.setScaleType(ImageView.ScaleType.FIT_XY);
        String imag3 = park.getParkimagesrc3();
        int imgid3 = getResources().getIdentifier(imag3, "drawable","com.example.ll.project_main");
        iv3.setBackgroundResource(imgid3);
//        int resID3 = getResources().getIdentifier(imag3,"drawable",appInfo.packageName);
//        Bitmap image3 = BitmapFactory.decodeResource(getResources(),resID3);
//        iv3.setImageBitmap(image3);
        list.add(iv3);

        pager.setAdapter(new MyPagerAdapter());
        //监听ViewPager滑动效果
        pager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {

            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {

            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });

    }



    //定义ViewPager的适配器
    class MyPagerAdapter extends PagerAdapter {
        //计算需要多少item显示
        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
            return view==o;
        }
        //初始化item实例方法
        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            container.addView(list.get(position)) ;
            return list.get(position);
        }
        //item销毁的方法
        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {

            // super.destroyItem(container, position, object);
            container.removeView(list.get(position));
        }
    }


    private class MySceneThread implements Runnable {
        @Override
        public void run() {
            Intent intent = getIntent();
            final ParkBean newpark =  ViewPark.executeHttpPost(intent.getStringExtra("title1"));
//            Log.e("hahaha",newpark.toString());
            insert(newpark);

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    initViewPager(newpark);

                }
            });
        }
    }
}

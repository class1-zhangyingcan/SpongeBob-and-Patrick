package com.example.ll.project_main.Activity.findActivity;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;

import com.example.ll.project_main.R;

public class addInteractFailure extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.addinteract_failure );
    }
}

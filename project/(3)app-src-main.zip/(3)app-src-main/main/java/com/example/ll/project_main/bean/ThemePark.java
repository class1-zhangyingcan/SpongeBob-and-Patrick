package com.example.ll.project_main.bean;

public class ThemePark {
    public int themeparkid;
    public String themeparktitle;
    public String themeparkscore;
    public String themeparkcontent;
    public String themeparkimage;
    public String themeparkdistance;
    public String themeparkprice;

    public int getThemeparkid() {
        return themeparkid;
    }

    public void setThemeparkid(int themeparkid) {
        this.themeparkid = themeparkid;
    }

    public String getThemeparktitle() {
        return themeparktitle;
    }

    public void setThemeparktitle(String themeparktitle) {
        this.themeparktitle = themeparktitle;
    }

    public String getThemeparkscore() {
        return themeparkscore;
    }

    public void setThemeparkscore(String themeparkscore) {
        this.themeparkscore = themeparkscore;
    }

    public String getThemeparkcontent() {
        return themeparkcontent;
    }

    public void setThemeparkcontent(String themeparkcontent) {
        this.themeparkcontent = themeparkcontent;
    }

    public String getThemeparkimage() {
        return themeparkimage;
    }

    public void setThemeparkimage(String themeparkimage) {
        this.themeparkimage = themeparkimage;
    }

    public String getThemeparkdistance() {
        return themeparkdistance;
    }

    public void setThemeparkdistance(String themeparkdistance) {
        this.themeparkdistance = themeparkdistance;
    }

    public String getThemeparkprice() {
        return themeparkprice;
    }

    public void setThemeparkprice(String themeparkprice) {
        this.themeparkprice = themeparkprice;
    }

    public ThemePark() {
    }

    public ThemePark(int themeparkid, String themeparktitle, String themeparkscore, String themeparkcontent, String themeparkimage, String themeparkdistance, String themeparkprice) {
        this.themeparkid = themeparkid;
        this.themeparktitle = themeparktitle;
        this.themeparkscore = themeparkscore;
        this.themeparkcontent = themeparkcontent;
        this.themeparkimage = themeparkimage;
        this.themeparkdistance = themeparkdistance;
        this.themeparkprice = themeparkprice;
    }
}

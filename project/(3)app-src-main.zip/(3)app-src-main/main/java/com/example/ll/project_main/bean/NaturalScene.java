package com.example.ll.project_main.bean;

public class NaturalScene {
    public int sceneid;
    public String scenetitle;
    public String scenescore;
    public String scenecontent;
    public String sceneimage;
    public String scenedistance;
    public String sceneprice;

    public int getSceneid() {
        return sceneid;
    }

    public void setSceneid(int sceneid) {
        this.sceneid = sceneid;
    }

    public String getScenetitle() {
        return scenetitle;
    }

    public void setScenetitle(String scenetitle) {
        this.scenetitle = scenetitle;
    }

    public String getScenescore() {
        return scenescore;
    }

    public void setScenescore(String scenescore) {
        this.scenescore = scenescore;
    }

    public String getScenecontent() {
        return scenecontent;
    }

    public void setScenecontent(String scenecontent) {
        this.scenecontent = scenecontent;
    }

    public String getSceneimage() {
        return sceneimage;
    }

    public void setSceneimage(String sceneimage) {
        this.sceneimage = sceneimage;
    }

    public String getScenedistance() {
        return scenedistance;
    }

    public void setScenedistance(String scenedistance) {
        this.scenedistance = scenedistance;
    }

    public String getSceneprice() {
        return sceneprice;
    }

    public void setSceneprice(String sceneprice) {
        this.sceneprice = sceneprice;
    }

    @Override
    public String toString() {
        return "NaturalScene{" +
                "sceneid=" + sceneid +
                ", scenetitle='" + scenetitle + '\'' +
                ", scenescore='" + scenescore + '\'' +
                ", scenecontent='" + scenecontent + '\'' +
                ", sceneimage='" + sceneimage + '\'' +
                ", scenedistance='" + scenedistance + '\'' +
                ", sceneprice='" + sceneprice + '\'' +
                '}';
    }

    public NaturalScene(String scenetitle, String scenescore, String scenecontent, String sceneimage, String scenedistance, String sceneprice) {

        this.scenetitle = scenetitle;
        this.scenescore = scenescore;
        this.scenecontent = scenecontent;
        this.sceneimage = sceneimage;
        this.scenedistance = scenedistance;
        this.sceneprice = sceneprice;
    }

    public NaturalScene() {
    }
}

package com.example.ll.project_main;

import android.app.Activity;
import android.content.Intent;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;


public class UpdateMainActivity extends AppCompatActivity {

    private EditText editText2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_main);
        //修改标题栏title
//        ActionBar ac = getSupportActionBar();
//        ac.setTitle("修改信息");

        Intent intent = getIntent();

        int image = intent.getIntExtra("image1", 0);
        ImageView imageView = findViewById(R.id.iv_image);
        imageView.setImageResource(image);

        String text1 = intent.getStringExtra("text1");
        TextView textView1 = findViewById(R.id.tv_change);
        textView1.setText(text1);

        String text2 = intent.getStringExtra("text2");
        editText2 = findViewById(R.id.et_change);
        editText2.setText(text2);

        final int id = intent.getIntExtra("id", 0);
        Log.e("MyActivityId1", String.valueOf(id));

        Button cancel = findViewById(R.id.btn_cancle);
        Button ok = findViewById(R.id.btn_ok);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(id==0) {
                    new Thread(new MyThread()).start();
                    Log.e("xiugai", "1111");

                    EditText edit2 = findViewById(R.id.et_change);
                    String text2 = edit2.getText().toString();
                    Intent intent1 = new Intent();
                    intent1.putExtra("text2New", text2);
                    intent1.putExtra("id", id);
                    Log.e("MainActivityId2", String.valueOf(id));
                    setResult(2, intent1);
                    Log.e("text2New", text2);
                    finish();
                }
                if(id==1){
                    new Thread(new MyThread1()).start();
                    EditText edit2 = findViewById(R.id.et_change);
                    String text2 = edit2.getText().toString();
                    Intent intent1 = new Intent();
                    intent1.putExtra("text2New", text2);
                    intent1.putExtra("id", id);
                    Log.e("MainActivityId2", String.valueOf(id));
                    setResult(2, intent1);
                    Log.e("text2New", text2);
                    finish();
                }else if(id==2){
                    new Thread(new MyThread2()).start();
                    EditText edit2 = findViewById(R.id.et_change);
                    String text2 = edit2.getText().toString();
                    Intent intent1 = new Intent();
                    intent1.putExtra("text2New", text2);
                    intent1.putExtra("id", id);
                    Log.e("MainActivityId2", String.valueOf(id));
                    setResult(2, intent1);
                    Log.e("text2New", text2);
                    finish();
                }

            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(3, null);
                finish();
            }
        });
    }

    private class MyThread1 implements Runnable {
        @Override
        public void run() {
            Intent intent = getIntent();
            Boolean newmark = WebServiceMark.executeHttpPost(editText2.getText().toString(), intent.getStringExtra("phone1"));
            Log.e("xxx", "123");
            Log.e("xxx",editText2.getText().toString());
            showReq(newmark);
        }
        private void showReq(final Boolean newmark) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (newmark.equals("true")) {
                                Intent intent = new Intent(UpdateMainActivity.this, HeadActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                    }else{
                                Intent intent = new Intent(UpdateMainActivity.this, HeadActivity.class);
                                startActivity(intent);
                    }
              }
           });
      }
    }

    private class MyThread implements Runnable {

        @Override
        public void run() {
            Intent intent = getIntent();
            Boolean newemail = WebServiceMail.executeHttpPost(editText2.getText().toString(), intent.getStringExtra("phone1"));
            Log.e("xxx", "123");
            Log.e("xxx",editText2.getText().toString());
            showReq(newemail);
        }

        private void showReq(final Boolean newemail) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (newemail.equals("true")) {
                        Intent intent = new Intent(UpdateMainActivity.this, HeadActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    }else{
                        Intent intent = new Intent(UpdateMainActivity.this, HeadActivity.class);
                        startActivity(intent);
                    }
                }
            });
        }
    }

    private class MyThread2 implements Runnable {

        @Override
        public void run() {
            Intent intent = getIntent();
            Boolean newsex = WebServiceSex.executeHttpPost(editText2.getText().toString(), intent.getStringExtra("phone1"));
            Log.e("xxx", "123");
            Log.e("xxx",editText2.getText().toString());
            showReq(newsex);
        }

        private void showReq(final Boolean newsex) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (newsex.equals("true")) {
                        Intent intent = new Intent(UpdateMainActivity.this, HeadActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    }else{
                        Intent intent = new Intent(UpdateMainActivity.this, HeadActivity.class);
                        startActivity(intent);
                    }
                }
            });
        }
    }
}

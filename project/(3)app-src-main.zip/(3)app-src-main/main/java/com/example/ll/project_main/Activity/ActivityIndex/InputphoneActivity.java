package com.example.ll.project_main.Activity.ActivityIndex;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.example.ll.project_main.R;

public class InputphoneActivity extends AppCompatActivity{
    private Button btngetcode;
    private CountTimer countTimer;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.input_phone);
        countTimer = new CountTimer(60000,1000);
        //获取验证码按钮
        btngetcode = findViewById( R.id.btn_getcode);
        //点击了获取验证码按钮，开始计时
        btngetcode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                countTimer.start();
            }
        });
    }
    //每隔一分钟，可点击一次验证码
    public class CountTimer extends CountDownTimer{

        /**
         * @param millisInFuture    The number of millis in the future from the call
         *   //时间间隔是多长时间                      to {@link #start()} until the countdown is done and {@link #onFinish()}
         *                          is called.
         * @param countDownInterval The interval along the way to receive
         *   回调onTick方法，多长时间执行一次                   {@link #onTick(long)} callbacks.
         */
        public CountTimer(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }
        //间隔时间内执行的操作
        @Override
        public void onTick(long millisUntilFinished) {
            //更新页面组件
            btngetcode.setText(millisUntilFinished/1000+"后重新发送");
            btngetcode.setBackgroundResource(R.drawable.btn_press);
            btngetcode.setClickable(false);

        }
        //间隔时间结束的时候调用
        @Override
        public void onFinish() {
            //更新页面组件
            btngetcode.setText(R.string.register_get_check_num);
            //btngetcode.setBackgroundResource();
            btngetcode.setClickable(true);
        }
    }
}

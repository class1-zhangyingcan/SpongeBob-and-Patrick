package com.example.ll.project_main;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.ll.project_main.Activity.findActivity.add_interact;
import com.example.ll.project_main.Utils.LlUtils;
import com.example.ll.project_main.Utils.WebServiceInteractGet;
import com.example.ll.project_main.bean.InteractBean;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ViewInject;

import java.util.List;


public class HomeFind extends Fragment {
    private boolean isSetPraise;
    @ViewInject( R.id.lv_interact_list )
    private ListView interactList;
    @ViewInject( R.id.iv_add_interact_msg )
    private ImageView addInteractMsg;
    private List<InteractBean> list;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate( R.layout.home_find,null );
        ViewUtils.inject(this,view);
        //获取数据并显示
        interactList.setAdapter( new interactAdapter() );
        return view;
    }


    public  class interactAdapter extends BaseAdapter{

        //计算需要适配的数据总量
        @Override
        public int getCount() {
            return LlUtils.userNameSort.length ;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        //item对应的view的数据渲染
        @Override
        public View getView(int position, View convertView, final ViewGroup parent) {
        MyHolder myHolder = null;
        if(convertView==null){
            myHolder = new MyHolder();
            convertView = LayoutInflater.from( parent.getContext()).inflate( R.layout.find_item,null );
            ViewUtils.inject(myHolder,convertView);
            convertView.setTag( myHolder );//

        }else{
            myHolder = (MyHolder) convertView.getTag();
        }

            myHolder.userNameTextView.setText( LlUtils.userNameSort[position]);
            myHolder.userTouxiang.setImageResource( LlUtils.userPhotoSort[position] );
            myHolder.interactTime.setText( LlUtils.interactTimeSort[position] );
            myHolder.interactContent.setText( LlUtils.interactSort[position] );
            myHolder.interactImage.setImageResource( LlUtils.interactPhoto[position] );
            myHolder.interactNumber.setText( String.valueOf( LlUtils.praiseNumber ) );
            final MyHolder finalMyHolder = myHolder;
            final MyHolder finalMyHolder1 = myHolder;
            myHolder.setPraiseNumber.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finalMyHolder.interactNumber.setText(String.valueOf( LlUtils.praiseNumber ));
                int number = LlUtils.praiseNumber;

                if(isSetPraise==false){
                    finalMyHolder1.setPraiseNumber.setImageResource( R.drawable.dianzan_pressed );
                    isSetPraise = true;
                    number++;
                    Log.e( "现在点赞人数：", String.valueOf( number ) );
                    finalMyHolder.interactNumber.setText( String.valueOf( number  ) );
                }else{
                    finalMyHolder1.setPraiseNumber.setImageResource( R.drawable.dianzan );
                    isSetPraise=false;
                    Log.e( "现在点赞人数：", String.valueOf( number ) );
                    finalMyHolder.interactNumber.setText( String.valueOf( number  ) );
                }

            }

        } );
        //选中点击
        //if()

            return convertView;
        }
    }
    public class MyHolder{
        @ViewInject( R.id.tv_users_name )
        private TextView userNameTextView;
        @ViewInject( R.id.iv_users_touxiang )
        private ImageView userTouxiang;
        @ViewInject( R.id.tv_interact_time )
        private TextView interactTime;
        @ViewInject( R.id.tv_users_content )
        private TextView interactContent;
        @ViewInject( R.id.iv_users_image )
        private ImageView interactImage;
        @ViewInject( R.id.tv_setPraiseNumber )
        private TextView interactNumber;
        @ViewInject( R.id.iv_dianzan_bottom )
        private ImageView setPraiseNumber;

    }





    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated( savedInstanceState );
        addInteractMsg.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( getActivity(),add_interact.class );
                startActivity( intent );
            }
        } );
        Button btnContect = getView().findViewById( R.id.btn_contect );
        btnContect.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new MyInteractThread()).start();
                Log.e( "zxl","zhixingle " );
            }
        } );
    }

    private class MyInteractThread implements Runnable {

        @Override
        public void run() {
            list =  WebServiceInteractGet.executeHttpInteract();
            Log.e( "homefindrun",list.toString() );
        }
    }
}

package com.example.ll.project_main.bean;

public class AmusePark {
    public int amuseid;
    public String amusetitle;
    public String amusescore;
    public String amusecontent;
    public String amuseimage;
    public String amusedistance;
    public String amuseprice;

    public int getAmuseid() {
        return amuseid;
    }

    public void setAmuseid(int amuseid) {
        this.amuseid = amuseid;
    }

    public String getAmusetitle() {
        return amusetitle;
    }

    public void setAmusetitle(String amusetitle) {
        this.amusetitle = amusetitle;
    }

    public String getAmusescore() {
        return amusescore;
    }

    public void setAmusescore(String amusescore) {
        this.amusescore = amusescore;
    }

    public String getAmusecontent() {
        return amusecontent;
    }

    public void setAmusecontent(String amusecontent) {
        this.amusecontent = amusecontent;
    }

    public String getAmuseimage() {
        return amuseimage;
    }

    public void setAmuseimage(String amuseimage) {
        this.amuseimage = amuseimage;
    }

    public String getAmusedistance() {
        return amusedistance;
    }

    public void setAmusedistance(String amusedistance) {
        this.amusedistance = amusedistance;
    }

    public String getAmuseprice() {
        return amuseprice;
    }

    public void setAmuseprice(String amuseprice) {
        this.amuseprice = amuseprice;
    }

    public AmusePark() {
    }

    public AmusePark(int amuseid, String amusetitle, String amusescore, String amusecontent, String amuseimage, String amusedistance, String amuseprice) {
        this.amuseid = amuseid;
        this.amusetitle = amusetitle;
        this.amusescore = amusescore;
        this.amusecontent = amusecontent;
        this.amuseimage = amuseimage;
        this.amusedistance = amusedistance;
        this.amuseprice = amuseprice;
    }
}

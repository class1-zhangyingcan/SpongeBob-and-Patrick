package com.example.ll.project_main.Activity.ActivityIndex;

import android.util.Log;

import com.example.ll.project_main.bean.ParkBean;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class ViewPark {
    public static ParkBean executeHttpPost(String parkname) {
        ParkBean parkBean = new ParkBean();
        try {
            URL url = new URL(com.example.ll.project_main.Utils.Url.getUrl()+"ParkLet?parkname="+parkname);
            Log.d("22","333");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestProperty("contentType", "UTF-8");


            InputStream in = connection.getInputStream();
            Log.e("jinlaile","333");


            //字节流转字符流
            InputStreamReader inputStreamReader = new InputStreamReader(in);
            BufferedReader reader = new BufferedReader(inputStreamReader);
            String str = reader.readLine();

            //解析JSONArray字符串
            JSONArray array = new JSONArray(str);

            //      for (int i = 0; i < array.length(); i++) {

            JSONObject object = array.getJSONObject(0);
            Log.e( "ceshi",object.getString( "parkcontent" ) );
            parkBean.setParkimagesrc1(object.getString("parkimagesrc1"));
            parkBean.setParkimagesrc2(object.getString("parkimagesrc2"));
            parkBean.setParkimagesrc3(object.getString("parkimagesrc3"));
            parkBean.setParkname(object.getString("parkname"));
            parkBean.setParkcontent(object.getString("parkcontent"));
            parkBean.setParkscore(object.getString("parkscore"));
            parkBean.setParkdistance(object.getString("parkdistance"));
            parkBean.setParklocation(object.getString("parklocation"));
            parkBean.setParkopentime(object.getString("parkopentime"));
            //   scenes.add(scene);
            //    }
            Log.e("Scene", parkBean.getParkdistance());
            Log.e("Scene", str);
            return parkBean;


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }
}

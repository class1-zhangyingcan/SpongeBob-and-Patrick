package com.example.ll.project_main.bean;

public class WaterPark {
    public int waterid;
    public String watertitle;
    public String waterscore;
    public String watercontent;
    public String waterimage;
    public String waterdistance;
    public String waterprice;

    public WaterPark() {
    }

    public WaterPark(int waterid, String watertitle, String waterscore, String watercontent, String waterimage, String waterdistance, String waterprice) {
        this.waterid = waterid;
        this.watertitle = watertitle;
        this.waterscore = waterscore;
        this.watercontent = watercontent;
        this.waterimage = waterimage;
        this.waterdistance = waterdistance;
        this.waterprice = waterprice;
    }

    public int getWaterid() {
        return waterid;
    }

    public void setWaterid(int waterid) {
        this.waterid = waterid;
    }

    public String getWatertitle() {
        return watertitle;
    }

    public void setWatertitle(String watertitle) {
        this.watertitle = watertitle;
    }

    public String getWaterscore() {
        return waterscore;
    }

    public void setWaterscore(String waterscore) {
        this.waterscore = waterscore;
    }

    public String getWatercontent() {
        return watercontent;
    }

    public void setWatercontent(String watercontent) {
        this.watercontent = watercontent;
    }

    public String getWaterimage() {
        return waterimage;
    }

    public void setWaterimage(String waterimage) {
        this.waterimage = waterimage;
    }

    public String getWaterdistance() {
        return waterdistance;
    }

    public void setWaterdistance(String waterdistance) {
        this.waterdistance = waterdistance;
    }

    public String getWaterprice() {
        return waterprice;
    }

    public void setWaterprice(String waterprice) {
        this.waterprice = waterprice;
    }
}

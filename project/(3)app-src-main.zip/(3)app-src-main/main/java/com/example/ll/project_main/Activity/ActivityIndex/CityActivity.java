//package com.example.ll.project_main.Activity.ActivityIndex;
//
//import android.app.Activity;
//import android.content.Intent;
//import android.os.AsyncTask;
//import android.os.Bundle;
//import android.support.annotation.Nullable;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Adapter;
//import android.widget.AdapterView;
//import android.widget.BaseAdapter;
//import android.widget.ListView;
//import android.widget.TextView;
//
//import com.example.ll.project_main.R;
//import com.example.ll.project_main.Utils.CONSTS;
//import com.example.ll.project_main.Utils.City;
//import com.example.ll.project_main.Utils.ResponseObject;
//import com.google.gson.Gson;
//import com.google.gson.reflect.TypeToken;
//import com.lidroid.xutils.ViewUtils;
//import com.lidroid.xutils.view.annotation.ViewInject;
//import com.lidroid.xutils.view.annotation.event.OnClick;
//import com.lidroid.xutils.view.annotation.event.OnItemClick;
//
//import org.apache.http.HttpResponse;
//import org.apache.http.client.HttpClient;
//import org.apache.http.client.methods.HttpPost;
//import org.apache.http.impl.client.DefaultHttpClient;
//import org.apache.http.util.EntityUtils;
//import org.w3c.dom.Text;
//
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;
//
//public class CityActivity extends Activity{
//
//    private ListView listDatas;
//    private List<City> cityList;
//
//    @Override
//    protected void onCreate(@Nullable Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.home_city_list);
//        listDatas = findViewById( R.id.city_list);
//        View view = LayoutInflater.from(this).inflate(R.layout.home_city_search,null);
//        listDatas.addHeaderView(view);
//
//        //点击返回键时
//        TextView cityback = findViewById(R.id.index_city_back);
//        cityback.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//            }
//        });
//        //点击每一个城市的listview时
//        ListView citylist = findViewById(R.id.city_list);
//        citylist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//
//            }
//        });
//
//        //点击刷新建时
//        TextView cityflush  = findViewById(R.id.index_city_flushcity);
//        cityflush.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//            }
//        });
//        //执行异步任务
//        new CityDataTask().execute();
//
//    }
//
//
//    //使用异步任务获取城市的json串
//    public class CityDataTask extends AsyncTask<Void,Void,List<City>>{
//
//        @Override
//        protected List<City> doInBackground(Void... voids) {
//            HttpClient client = new DefaultHttpClient();
//            HttpPost httpPost = new HttpPost(CONSTS.City_Data_URL);
//            try {
//                HttpResponse httpResponse = client.execute(httpPost);
//                if(httpResponse.getStatusLine().getStatusCode()==200){
//                    String jsonString = EntityUtils.toString(httpResponse.getEntity());
//                    return parseCityDatasJson(jsonString);
//                }
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//            return null;
//        }
//
//        @Override
//        protected void onPostExecute(List<City> cities) {
//
//            super.onPostExecute(cities);
//            cityList = cities;
//            //适配显示
//            MyAdapter adapter = new MyAdapter(cityList);
//            listDatas.setAdapter(adapter );
//        }
//    }
//    //解析城市数据的json
//    public List<City> parseCityDatasJson(String json){
//        Gson gson = new Gson();
//        ResponseObject<List<City>> responseObject = gson.fromJson(json,new TypeToken<ResponseObject<List<City>>>(){}.getType());
//        return responseObject.getDatas();
//
//    }
//    private StringBuffer buffer = new StringBuffer();
//    private List<String> firstList = new ArrayList<String>();
//    //适配器
//    public class MyAdapter extends BaseAdapter{
//        private List<City> listCityDatas;
//
//        public MyAdapter(List<City> listCityDatas) {
//            this.listCityDatas = listCityDatas;
//        }
//
//        @Override
//        public int getCount() {
//            return listCityDatas.size();
//        }
//
//        @Override
//        public Object getItem(int position) {
//            return listCityDatas.get(position);
//        }
//
//        @Override
//        public long getItemId(int position) {
//            return position;
//        }
//
//        @Override
//        public View getView(int position, View convertView, ViewGroup parent) {
//            Holder holder;
//            if(convertView==null){
//                holder = new Holder();
//                convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_city_item,null );
//                ViewUtils.inject(holder,convertView);
//                convertView.setTag(holder);
//
//            }else {
//                holder = (Holder) convertView.getTag();
//            }
//            //数据显示处理
//            City city = listCityDatas.get(position);
//            String sort = city.getSortkey();
//            String name = city.getName();
//            if(buffer.indexOf(sort)==-1){
//                buffer.append(sort);
//                firstList.add(name);
//            }
//            if(firstList.contains(name)){
//                holder.keySort.setText(sort);
//                holder.keySort.setVisibility(View.VISIBLE);
//            }else {
//                holder.keySort.setVisibility(View.GONE);
//            }
//            holder.cityName.setText(name);
//            return convertView;
//        }
//    }
//    public class Holder{
//        @ViewInject(R.id.city_list_item_sort)
//        public TextView keySort;
//        @ViewInject(R.id.city_list_item_name)
//        public TextView cityName;
//    }
//}

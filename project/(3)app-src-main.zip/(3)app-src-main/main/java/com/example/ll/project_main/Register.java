package com.example.ll.project_main;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.mob.MobSDK;

import cn.smssdk.EventHandler;
import cn.smssdk.SMSSDK;

public class Register extends AppCompatActivity implements View.OnClickListener {

    private TimeCount times;
    private EditText edit_phone;
    private EditText edit_cord;
    private TextView now;
    private String cord_number;
    EventHandler eventHandler;
    private int time = 60;
    private boolean flag = true;

    private Button btn_getCord;
    private Button btn_register;
    private String phone_number;

    private EditText regUserName;
    private EditText regPassWord;
    private EditText regConfirmPassWord;
    private EditText regPhone;
    private Button btn_reg;

    ProgressDialog dialog;



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_main);

        View v0 = findViewById(R.id.background);
        v0.getBackground().setAlpha(200);

        View v = findViewById(R.id.bg);
        v.getBackground().setAlpha(100);

        View v1 = findViewById(R.id.bg1);
        v1.getBackground().setAlpha(100);

        View v2 = findViewById(R.id.bg2);
        v2.getBackground().setAlpha(100);

        View v3 = findViewById(R.id.bg3);
        v3.getBackground().setAlpha(100);

        View v4 = findViewById(R.id.bg4);
        v4.getBackground().setAlpha(120);



        MobSDK.init(this,"28f3d3389db6c","425d81d5ac53c59f01640ef8c6905a4c");


        regUserName = (EditText)findViewById(R.id.reg_username);
        regUserName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){

                }else {
                    if ("".equals(regUserName.getText().toString())) {
                        Toast.makeText(Register.this, "用户名不能为空", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        regPassWord = (EditText)findViewById(R.id.password);
        regPassWord.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){

                }else {
                    if ("".equals(regPassWord.getText().toString())) {
                        Toast.makeText(Register.this, "密码不能为空", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        regConfirmPassWord = (EditText)findViewById(R.id.confirm_password);
        regConfirmPassWord.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){

                }else {
                    if (!((regConfirmPassWord.getText().toString()).equals(regPassWord.getText().toString()))) {
                        Toast.makeText(Register.this, "两次密码输入不一致", Toast.LENGTH_LONG).show();
                    }
                }
            }
        });
        regPhone = (EditText)findViewById(R.id.edit_phone);
        btn_reg = (Button)findViewById(R.id.btn_register);
        btn_reg.getBackground().setAlpha(80);
        btn_reg.setOnClickListener(this);




        getId();

        times = new TimeCount(60000,1000);

        eventHandler = new EventHandler() {
            public void afterEvent(int event, int result, Object data) {
                Message msg = new Message();
                msg.arg1 = event;
                msg.arg2 = result;
                msg.obj = data;
                handler.sendMessage(msg);
            }
        };

        SMSSDK.registerEventHandler(eventHandler);

    }


    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_register:
                if (judCord())
                    SMSSDK.submitVerificationCode("86", phone_number, cord_number);
                flag = false;
                break;
            case R.id.btn_getcord:
                if (judPhone())//去掉左右空格获取字符串
                {
                    times.start();
                    SMSSDK.getVerificationCode("86", phone_number);
                    edit_cord.requestFocus();
                }
                break;
            default:
                break;
        }
    }


    private boolean judPhone() {
        if (TextUtils.isEmpty(edit_phone.getText().toString().trim())) {
            Toast.makeText(Register.this, "请输入您的手机号", Toast.LENGTH_LONG).show();
            edit_phone.requestFocus();
            return false;
        } else if (edit_phone.getText().toString().trim().length() != 11) {
            Toast.makeText(Register.this, "您的手机号位数不正确", Toast.LENGTH_LONG).show();
            edit_phone.requestFocus();
            return false;
        } else {
            phone_number = edit_phone.getText().toString().trim();
            String num = "[1][358]\\d{9}";
            if (phone_number.matches(num))
                return true;
            else {
                Toast.makeText(Register.this, "请输入正确的手机号码", Toast.LENGTH_LONG).show();
                return false;
            }
        }
    }

    private boolean judCord() {
        judPhone();
        if (TextUtils.isEmpty(edit_cord.getText().toString().trim())) {
            Toast.makeText(Register.this, "请输入您的验证码", Toast.LENGTH_LONG).show();
            edit_cord.requestFocus();
            return false;
        } else if (edit_cord.getText().toString().trim().length() != 4) {
            Toast.makeText(Register.this, "您的验证码位数不正确", Toast.LENGTH_LONG).show();
            edit_cord.requestFocus();

            return false;
        } else {
            cord_number = edit_cord.getText().toString().trim();
            return true;
        }

    }

    private class TimeCount extends CountDownTimer {
        /**
         * @param millisInFuture    The number of millis in the future from the call
         *                          to {@link #start()} until the countdown is done and {@link #onFinish()}
         *                          is called.
         * @param countDownInterval The interval along the way to receive
         *                          {@link #onTick(long)} callbacks.
         */
        public TimeCount(long millisInFuture, long countDownInterval) {
            super(millisInFuture, countDownInterval);
        }

        @Override
        public void onTick(long millisUntilFinished) {
            btn_getCord.setClickable(false);
            btn_getCord.setText(millisUntilFinished / 1000 + "s");
        }

        @Override
        public void onFinish() {
            btn_getCord.setText("获取验证码");
            btn_getCord.setClickable(true);
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        SMSSDK.unregisterEventHandler(eventHandler);
    }

    /**
     * 使用Handler来分发Message对象到主线程中，处理事件
     */
    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            int event = msg.arg1;
            int result = msg.arg2;
            Object data = msg.obj;
            if (event == SMSSDK.EVENT_GET_VERIFICATION_CODE) {
                if (result == SMSSDK.RESULT_COMPLETE) {
                    boolean smart = (Boolean) data;
                    if (smart) {
                        Toast.makeText(getApplicationContext(), "该手机号已经注册过，请重新输入",
                                Toast.LENGTH_LONG).show();
                        edit_phone.requestFocus();
                        return;
                    }
                }
            }
            if (result == SMSSDK.RESULT_COMPLETE) {

                if (event == SMSSDK.EVENT_SUBMIT_VERIFICATION_CODE) {
                    Toast.makeText(getApplicationContext(), "验证码输入正确",
                            Toast.LENGTH_LONG).show();
                    dialog = new ProgressDialog(Register.this);
                    dialog.setTitle("正在注册");
                    dialog.setMessage("请稍后");
                    dialog.show();

                    new Thread(new RegThread()).start();


                }
            } else {
                if (flag) {
                    btn_getCord.setVisibility(View.VISIBLE);
                    Toast.makeText(getApplicationContext(), "验证码获取失败请重新获取", Toast.LENGTH_LONG).show();
                    edit_phone.requestFocus();
                } else {
                    Toast.makeText(getApplicationContext(), "验证码输入错误", Toast.LENGTH_LONG).show();
                }
            }

        }

    };

    /**
     * 获取id
     */
    private void getId() {
        edit_phone = findViewById(R.id.edit_phone);
        edit_cord = findViewById(R.id.edit_code);
        btn_getCord = findViewById(R.id.btn_getcord);
        btn_register = findViewById(R.id.btn_register);
        btn_getCord.setOnClickListener(this);
        btn_register.setOnClickListener(this);
    }
    private class RegThread implements Runnable {
        @Override
        public void run() {
            //获取服务器返回数据
            //String RegRet = WebServiceGet.executeHttpGet(regUserName.getText().toString(),regPassWord.getText().toString(),"RegLet");
            String RegRet = WebServicePost.executeHttpPost(regUserName.getText().toString(),regPassWord.getText().toString(),regPhone.getText().toString(),"RegLet");


            //更新UI，界面处理
            showReq(RegRet);
        }

        private void showReq(final String RegRet) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Log.e("222","2222");
                    if("true".equals(RegRet)){
                        Log.e("222","2");
                        dialog.dismiss();
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("注册信息");
                        builder.setMessage("注册成功");
                        builder.setCancelable(false);
                        builder.setPositiveButton("OK",new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                new Thread(new MyThread()).start();
                                Intent intent = new Intent(Register.this,Login.class);
                                startActivity(intent);
                            }
                        });
                        builder.show();
                    }else{
                        dialog.dismiss();
                        AlertDialog.Builder builder = new AlertDialog.Builder(Register.this);
                        builder.setTitle("注册信息");
                        builder.setMessage("注册失败");
                        builder.setCancelable(false);
                        builder.setPositiveButton("OK",new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Intent intent = new Intent(Register.this,Login.class);
                                startActivity(intent);
                            }
                        });
                        builder.show();
                    }
                }
            });
        }
    }

    private class MyThread implements Runnable {
        @Override
        public void run() {
            Boolean newuser = WebServicePhone.executeHttpGet("mark","sex","email",edit_phone.getText().toString());
            Log.e("xxx", "123");
            showReq(newuser);
        }
    }

    private void showReq(final Boolean newuser) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (newuser.equals("true")) {
                    Toast.makeText(Register.this,"插入成功！", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(Register.this,"插入失败！", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

package com.example.ll.project_main;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

public class WelcomeGuideActivity extends Activity{

    private Button btn;
    private ViewPager pager;
    private List<View> list;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome_guide);
        btn = findViewById(R.id.welcome_guide_btn);
        pager = findViewById(R.id.welcome_pager);

        initViewPager();
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getBaseContext(),Login.class));
                finish();
            }
        });
    }

    //初始化View Pager的方法
    public void initViewPager() {
        list = new ArrayList<View>();
        ImageView iv = new ImageView(this);

        iv.setImageResource(R.drawable.banner11);
        iv.setScaleType(ImageView.ScaleType.FIT_XY);

        list.add(iv);
        ImageView iv1 = new ImageView(this);
        iv1.setImageResource(R.drawable.banner22);
        iv1.setScaleType(ImageView.ScaleType.FIT_XY);

        list.add(iv1);
        ImageView iv2 = new ImageView(this);
        iv2.setImageResource(R.drawable.banner33);
        iv2.setScaleType(ImageView.ScaleType.FIT_XY);


        list.add(iv2);

        pager.setAdapter(new MyPagerAdapter());
        //监听ViewPager滑动效果
        pager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }
            //页卡被选中的方法
            @Override
            public void onPageSelected(int i) {
                //如果是第三个页面
                if(i==2){
                    btn.setVisibility(View.VISIBLE);
                }else {
                    btn.setVisibility(View.GONE);
                }
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });

    }
    //定义ViewPager的适配器
    class MyPagerAdapter extends PagerAdapter {
        //计算需要多少item显示
        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
            return view==o;
        }
        //初始化item实例方法
        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            container.addView(list.get(position)) ;
            return list.get(position);
        }
        //item销毁的方法
        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {

            // super.destroyItem(container, position, object);
            container.removeView(list.get(position));
        }
    }
}

package service;

import java.sql.Connection;

import bean.Foodculture;
import bean.History;
import bean.Naturalscene;
import bean.ParkBean;
import bean.Scene;
import bean.Scenes;
import bean.Humanityhistory;
import bean.InteractBean;
import bean.MineBean;
import bean.Waterpark;
import bean.Foodculture;
import bean.Themepark;
import bean.UserBean;
import bean.Amusepark;
import bean.Food;
import bean.FoodBean;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import db.DBManager;

public class Service {
	public Boolean login(String userphone, String password) {

        // 获取Sql查询语句
		
		
		
        String logSql = "select * from users where user_phone= '" + userphone +  "' and user_psw= '" + password + "'";

        // 获取DB对象
        DBManager sql = DBManager.createInstance();
        sql.connectDB();

        // 操作DB对象
        try {
            ResultSet rs = sql.executeQuery(logSql);
            if (rs.next()) {
                sql.closeDB();
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        sql.closeDB();
        return false;
    }

    public Boolean register(String username, String password,String phone) {
    	
    	   
    	// 获取Sql查询语句
        String regSql = "insert into users(user_name,user_psw,user_phone) "
        		+ "values('"+ username+ "','"+ password+ "','"+ phone+ "') ";

        // 获取DB对象
        DBManager sql = DBManager.createInstance();
        sql.connectDB();

        int ret = sql.executeUpdate(regSql);
        if (ret != 0) {
            sql.closeDB();
            return true;
        }
        sql.closeDB();
        
        return false;
    }
    
    
    
    public List<Scenes> Scenes() {

		// 获取Sql查询语句

		List<Scenes> scenelist = new ArrayList<Scenes>();

		String logSql = "select * from scenes";

		// 获取DB对象
		DBManager sql = DBManager.createInstance();
		sql.connectDB();

		// 操作DB对象
		try {
			ResultSet rs = sql.executeQuery(logSql);
			while (rs.next()) {
				Scenes scenes = new Scenes();
				scenes.setSceneid(rs.getInt("scene_id"));
				scenes.setScenetitle(rs.getString("scene_title"));
				scenes.setScenescore(rs.getString("scene_score"));
				scenes.setScenecontent(rs.getString("scene_content"));
				scenes.setSceneimage(rs.getString("scene_image"));
				scenes.setScenedistance(rs.getString("scene_distance"));
				scenes.setSceneprice(rs.getString("scene_price"));

				scenelist.add(scenes);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return scenelist;
	}


//人文历史数据库获取
public List<History> History() {

	// 获取Sql查询语句

	List<History> historylist = new ArrayList<History>();

	String logSql = "select * from history";

	// 获取DB对象
	DBManager sql = DBManager.createInstance();
	sql.connectDB();

	// 操作DB对象
	try {
		ResultSet rs = sql.executeQuery(logSql);
		while (rs.next()) {
			History history = new History();
			history.setHistoryid(rs.getInt("history_id"));
			history.setHistorytitle(rs.getString("history_title"));
			history.setHistoryscore(rs.getString("history_score"));
			history.setHistorycontent(rs.getString("history_content"));
			history.setHistoryimage(rs.getString("history_image"));
			history.setHistorydistance(rs.getString("history_distance"));
			history.setHistoryprice(rs.getString("history_price"));

			historylist.add(history);
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return historylist;
}
public Scene Scene(String scenename) {

    // 获取Sql查询语句
	
	List<Scene> scenelist = new ArrayList<Scene>();
	
	
    String logSql = "select * from scene where scene_name= '" + scenename +  "'";

    // 获取DB对象
    DBManager sql = DBManager.createInstance();
    sql.connectDB();

    // 操作DB对象
    try {
        ResultSet rs = sql.executeQuery(logSql);

//      String sceneimagesrc1;
//		String sceneimagesrc2;
//		String sceneimagesrc3;
//		String scenerank;
//		String scenedistance;
//		String scenelocation;
//		String sceneopentime;
//		String sceneplaytime;
//		double scenemark;
		
	
        if (rs.next()) {
        	Scene scene = new Scene();
//        	admin.setAdminId(rs.getInt("admin_id"));
			scene.setSceneimagesrc1(rs.getString("scene_image_src1"));
			scene.setSceneimagesrc2(rs.getString("scene_image_src2"));
			scene.setSceneimagesrc3(rs.getString("scene_image_src3"));
			scene.setScenename(rs.getString("scene_name"));
			scene.setScenerank(rs.getString("scene_rank"));
			scene.setScenedistance(rs.getString("scene_distance"));
			scene.setScenelocation(rs.getString("scene_location"));
			scene.setSceneopentime(rs.getString("scene_open_time"));
			scene.setSceneplaytime(rs.getString("scene_play_time"));
			scene.setScenemark(rs.getDouble("scene_mark"));
			scenelist.add(scene);
            sql.closeDB();
            System.out.println(scene.getScenelocation());
            return scene;
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    sql.closeDB();
    return null;
}
//获取Foodculture界面信息
public List<Foodculture> FoodCultural() {

	// 获取Sql查询语句

	List<Foodculture> foodcultureslist = new ArrayList<Foodculture>();

	String logSql = "select * from foodculture";

	// 获取DB对象
	DBManager sql = DBManager.createInstance();
	sql.connectDB();

	// 操作DB对象
	try {
		ResultSet rs = sql.executeQuery(logSql);
		while (rs.next()) {
			Foodculture foodcultures = new Foodculture();
			foodcultures.setFoodcultureid(rs.getInt("foodculture_id"));
			foodcultures.setFoodculturetitle(rs.getString("foodculture_title"));
			foodcultures.setFoodculturescore(rs.getString("foodculture_score"));
			foodcultures.setFoodculturecontent(rs.getString("foodculture_content"));
			foodcultures.setFoodcultureimage(rs.getString("foodculture_image"));
			foodcultures.setFoodculturedistance(rs.getString("foodculture_distance"));
			foodcultures.setFoodcultureprice(rs.getString("foodculture_price"));

			foodcultureslist.add(foodcultures);
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return foodcultureslist;
}


//获取NatureScene界面信息
public List<Naturalscene> Naturalscenes() {

	// 获取Sql查询语句

	List<Naturalscene> naturalsceneslist = new ArrayList<Naturalscene>();

	String logSql = "select * from naturalscene";

	// 获取DB对象
	DBManager sql = DBManager.createInstance();
	sql.connectDB();

	// 操作DB对象
	try {
		ResultSet rs = sql.executeQuery(logSql);
		while (rs.next()) {
			Naturalscene naturalscenes = new Naturalscene();
			naturalscenes.setNaturalsceneid(rs.getInt("naturalscene_id"));
			naturalscenes.setNaturalscenetitle(rs.getString("naturalscene_title"));
			naturalscenes.setNaturalscenescore(rs.getString("naturalscene_score"));
			naturalscenes.setNaturalscenecontent(rs.getString("naturalscene_content"));
			naturalscenes.setNaturalsceneimage(rs.getString("naturalscene_image"));
			naturalscenes.setNaturalscenedistance(rs.getString("naturalscene_distance"));
			naturalscenes.setNaturalsceneprice(rs.getString("naturalscene_price"));

			naturalsceneslist.add(naturalscenes);
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return naturalsceneslist;
}

//获取Humanityhistory界面信息
public List<Humanityhistory> Humanityhistory() {

	// 获取Sql查询语句

	List<Humanityhistory> humanityhistories = new ArrayList<Humanityhistory>();

	String logSql = "select * from humanityhistory";

	// 获取DB对象
	DBManager sql = DBManager.createInstance();
	sql.connectDB();

	// 操作DB对象
	try {
		ResultSet rs = sql.executeQuery(logSql);
		while (rs.next()) {
			Humanityhistory humanityhistory = new Humanityhistory();
			humanityhistory.setHumanityid(rs.getInt("humanity_id"));
			humanityhistory.setHumanitytitle(rs.getString("humanity_title"));
			humanityhistory.setHumanityscore(rs.getString("humanity_score"));
			humanityhistory.setHumanitycontent(rs.getString("humanity_content"));
			humanityhistory.setHumanityimage(rs.getString("humanity_image"));
			humanityhistory.setHumanitydistance(rs.getString("humanity_distance"));
			humanityhistory.setHumanityprice(rs.getString("humanity_price"));

			humanityhistories.add(humanityhistory);
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return humanityhistories;
}

//获取Themepark界面信息
public List<Themepark> Themepark() {

	// 获取Sql查询语句

	List<Themepark> themeparks = new ArrayList<Themepark>();

	String logSql = "select * from themepark";

	// 获取DB对象
	DBManager sql = DBManager.createInstance();
	sql.connectDB();

	// 操作DB对象
	try {
		ResultSet rs = sql.executeQuery(logSql);
		while (rs.next()) {
			Themepark themepark = new Themepark();
			themepark.setThemeparkid(rs.getInt("themepark_id"));
			themepark.setThemeparktitle(rs.getString("themepark_title"));
			themepark.setThemeparkscore(rs.getString("themepark_score"));
			themepark.setThemeparkcontent(rs.getString("themepark_content"));
			themepark.setThemeparkimage(rs.getString("themepark_image"));
			themepark.setThemeparkdistance(rs.getString("themepark_distance"));
			themepark.setThemeparkprice(rs.getString("themepark_price"));

			themeparks.add(themepark);
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return themeparks;
}

//获取Waterpark界面信息
public List<Waterpark> Waterpark() {

	// 获取Sql查询语句

	List<Waterpark> waterparks = new ArrayList<Waterpark>();

	String logSql = "select * from waterpark";

	// 获取DB对象
	DBManager sql = DBManager.createInstance();
	sql.connectDB();

	// 操作DB对象
	try {
		ResultSet rs = sql.executeQuery(logSql);
		while (rs.next()) {
			Waterpark waterpark = new Waterpark();
			waterpark.setWaterid(rs.getInt("water_id"));
			waterpark.setWatertitle(rs.getString("water_title"));
			waterpark.setWaterscore(rs.getString("water_score"));
			waterpark.setWatercontent(rs.getString("water_content"));
			waterpark.setWaterimage(rs.getString("water_image"));
			waterpark.setWaterdistance(rs.getString("water_distance"));
			waterpark.setWaterprice(rs.getString("water_price"));

			waterparks.add(waterpark);
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return waterparks;
}
//获取Amusepark界面信息
public List<Amusepark> Amusepark() {

	// 获取Sql查询语句

	List<Amusepark> amuseparks = new ArrayList<Amusepark>();

	String logSql = "select * from amusepark";

	// 获取DB对象
	DBManager sql = DBManager.createInstance();
	sql.connectDB();

	// 操作DB对象
	try {
		ResultSet rs = sql.executeQuery(logSql);
		while (rs.next()) {
			Amusepark amusepark = new Amusepark();
			amusepark.setAmuseid(rs.getInt("amuse_id"));
			amusepark.setAmusetitle(rs.getString("amuse_title"));
			amusepark.setAmusescore(rs.getString("amuse_score"));
			amusepark.setAmusecontent(rs.getString("amuse_content"));
			amusepark.setAmuseimage(rs.getString("amuse_image"));
			amusepark.setAmusedistance(rs.getString("amuse_distance"));
			amusepark.setAmuseprice(rs.getString("amuse_price"));

			amuseparks.add(amusepark);
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return amuseparks;
}

//获取Food界面信息
public List<Food> Food() {

	// 获取Sql查询语句

	List<Food> foods = new ArrayList<Food>();

	String logSql = "select * from food";

	// 获取DB对象
	DBManager sql = DBManager.createInstance();
	sql.connectDB();

	// 操作DB对象
	try {
		ResultSet rs = sql.executeQuery(logSql);
		while (rs.next()) {
			Food food = new Food();
			food.setFoodid(rs.getInt("food_id"));
			food.setFoodtitle(rs.getString("food_title"));
			food.setFoodscore(rs.getString("food_score"));
			food.setFoodcontent(rs.getString("food_content"));
			food.setFoodimage(rs.getString("food_image"));
			food.setFooddistance(rs.getString("food_distance"));
			food.setFoodprice(rs.getString("food_price"));

			foods.add(food);
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return foods;
}
//动态放入到数据库
public Boolean putInteract(InteractBean interact){
	
	String interactSql = "insert into interact(user_name,user_touxiang,interact_time,"
			+ "interact_content,interact_photo,interat_praise)values('"+interact.getUserName()+"',"
					+ "'"+interact.getUserTouxiang()+ "','"+interact.getInteractTime()+"',"
							+ "'"+interact.getInteractContent()+ "','"+interact.getInteractPhoto()+"',"
									+ "'"+interact.getInteractPraise()+"')";

    // 获取DB对象
    DBManager sql = DBManager.createInstance();
    sql.connectDB();

    int ret = sql.executeUpdate(interactSql);
    if (ret != 0) {
        sql.closeDB();
        return true;
    }
    sql.closeDB();
    
    return false;
}
//获取interact_find界面信息
public List<InteractBean> interactSelect() {

	// 获取Sql查询语句

	List<InteractBean> interacts = new ArrayList<InteractBean>();

	String interactSql = "select * from interact";

	// 获取DB对象
	DBManager sql = DBManager.createInstance();
	sql.connectDB();

	// 操作DB对象
	try {
		ResultSet rs = sql.executeQuery(interactSql);
		while (rs.next()) {
			InteractBean interact = new InteractBean();
			interact.setInteactId(rs.getInt("interact_id"));
			interact.setUserName(rs.getString("user_name"));
			interact.setUserTouxiang(rs.getString("user_touxiang"));
			interact.setInteractTime(rs.getString("interact_time"));
			interact.setInteractContent(rs.getString("interact_content"));
			interact.setInteractPhoto(rs.getString("interact_photo"));
			interact.setInteractPraise(rs.getString("interact_praise"));
			interacts.add(interact);
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return interacts;
}
//我的mine
public UserBean loginphone(String phone) {
	List<UserBean> userlist=new ArrayList<UserBean>();
	String logpSql="select * from users where user_phone='" + phone + "'";

	// 获取DB对象
    DBManager sql = DBManager.createInstance();
    sql.connectDB();

    ResultSet ret = sql.executeQuery(logpSql);
    try {
		if (ret.next()) {
			UserBean user=new UserBean();
			user.setUserName(ret.getString("user_name"));
			user.setUserPhone(ret.getString("user_phone"));
			user.setUserPsw(ret.getString("user_psw"));
			userlist.add(user);
		    sql.closeDB();
		    System.out.println(user.getUserName());
		    return user;
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    sql.closeDB();
    
    return null;
}
public MineBean phone(String mark,String sex,String email,String phone) {
	List<MineBean> userlist=new ArrayList<MineBean>();
	//获取sql语句
	String pSql="insert into mine(user_mark,user_sex,user_email,user_phone) values('"+mark+ "','"+ sex+ "','"+ email+ "','"+phone+"') ";
	//获取DB对象
    DBManager sql = DBManager.createInstance();
    sql.connectDB();

    int ret = sql.executeUpdate(pSql);
    if (ret!=0) {
		MineBean mine=new MineBean();
		mine.setUserPhone("user_phone");
		mine.setUserMark("user_mark");
		mine.setUserSex("user_sex");
		mine.setUserEmail("user_email");
		userlist.add(mine);
	    sql.closeDB();
	    return mine;
	}
    sql.closeDB();
    
    return null;
}
public MineBean mine1(String mark,String phone) {
	List<MineBean> userlist=new ArrayList<MineBean>();
    // 获取Sql查询语句
    String mineSql1 = "update mine set user_mark='"+ mark +"' where user_phone='" + phone + "';";

    // 获取DB对象
    DBManager sql = DBManager.createInstance();
    sql.connectDB();

    int ret = sql.executeUpdate(mineSql1);
    if (ret!=0) {
		MineBean mine1=new MineBean();
		mine1.setUserMark("user_mark");
		mine1.setUserPhone("user_phone");
		userlist.add(mine1);
	    sql.closeDB();
	    return mine1;
	}
    sql.closeDB();
    
    return null;
}

public MineBean mine2(String email,String phone) {
	List<MineBean> userlist=new ArrayList<MineBean>();
    // 获取Sql查询语句
    String mineSql2 = "update mine set user_email='"+ email +"' where user_phone='" + phone + "';";

    // 获取DB对象
    DBManager sql = DBManager.createInstance();
    sql.connectDB();

    int ret = sql.executeUpdate(mineSql2);
    if (ret!=0) {
		MineBean mine2=new MineBean();
		mine2.setUserMark("user_mark");
		mine2.setUserPhone("user_phone");
		userlist.add(mine2);
	    sql.closeDB();
	    return mine2;
	}
    sql.closeDB();
    
    return null;
}
public MineBean mine3(String sex,String phone) {
	List<MineBean> userlist=new ArrayList<MineBean>();
    // 获取Sql查询语句
    String mineSql3 = "update mine set user_sex='"+ sex +"' where user_phone='" + phone + "';";

    // 获取DB对象
    DBManager sql = DBManager.createInstance();
    sql.connectDB();

    int ret = sql.executeUpdate(mineSql3);
    if (ret!=0) {
		MineBean mine3=new MineBean();
		mine3.setUserMark("user_mark");
		mine3.setUserPhone("user_phone");
		userlist.add(mine3);
	    sql.closeDB();
	    return mine3;
	}
    sql.closeDB();
    
    return null;
}
public MineBean phoneselect(String phone) {
	List<MineBean> userlist=new ArrayList<MineBean>();
	 // 获取Sql查询语句
    String psSql = "select * from mine where user_phone='" + phone + "'";
 // 获取DB对象
    DBManager sql = DBManager.createInstance();
    sql.connectDB();

    ResultSet ret = sql.executeQuery(psSql);
    try {
		if (ret.next()) {
			MineBean mine=new MineBean();
			mine.setUserMark(ret.getString("user_mark"));
			mine.setUserSex(ret.getString("user_sex"));
			mine.setUserEmail(ret.getString("user_email"));
			mine.setUserPhone(ret.getString("user_phone"));

			userlist.add(mine);
		    sql.closeDB();
		    return mine;
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    sql.closeDB();
    
    return null;
}
//FoodTitle
public FoodBean foodtitle(String foodtitle) {
	List<FoodBean> foodlist=new ArrayList<FoodBean>();
	String foodSql="select * from viewfood where food_title='" + foodtitle + "'";

	// 获取DB对象
    DBManager sql = DBManager.createInstance();
    sql.connectDB();

    ResultSet ret = sql.executeQuery(foodSql);
    try {
		if (ret.next()) {
			FoodBean food=new FoodBean();
			food.setFoodimagesrc1(ret.getString("food_image_src1"));
			food.setFoodimagesrc2(ret.getString("food_image_src2"));
			food.setFoodimagesrc3(ret.getString("food_image_src3"));
			food.setFoodtitle(ret.getString("food_title"));
			food.setFoodcontent(ret.getString("food_content"));
			food.setFoodscore(ret.getString("food_score"));
			food.setFoodaddress(ret.getString("food_address"));
			food.setFoodtime(ret.getString("food_time"));
			food.setFoodlist(ret.getString("food_list"));
			food.setFooddish(ret.getString("food_dish"));
			foodlist.add(food);
		    sql.closeDB();
		    System.out.println(food.getFoodtitle());
		    return food;
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    sql.closeDB();
    
    return null;
}

//park
public ParkBean park(String parkname) {
	List<ParkBean> parklist=new ArrayList<ParkBean>();
	String parkSql="select * from viewpark where park_name='" + parkname + "'";

	// 获取DB对象
    DBManager sql = DBManager.createInstance();
    sql.connectDB();

    ResultSet ret = sql.executeQuery(parkSql);
    try {
		if (ret.next()) {
			ParkBean park=new ParkBean();
			park.setParkimagesrc1(ret.getString("park_image_src1"));
			park.setParkimagesrc2(ret.getString("park_image_src2"));
			park.setParkimagesrc3(ret.getString("park_image_src3"));
			park.setParkname(ret.getString("park_name"));
			park.setParkcontent(ret.getString("park_content"));
			park.setParkscore(ret.getString("park_score"));
			park.setParkdistance(ret.getString("park_distance"));
			park.setParklocation(ret.getString("park_location"));
			park.setParkopentime(ret.getString("park_open_time"));
			parklist.add(park);
		    sql.closeDB();
		    System.out.println(park.getParkdistance());
		    return park;
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    sql.closeDB();
    
    return null;
}


}

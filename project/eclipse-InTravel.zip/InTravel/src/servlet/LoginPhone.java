package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import bean.UserBean;
import service.Service;

/**
 * Servlet implementation class LoginPhone
 */
@WebServlet("/LoginPhone")
public class LoginPhone extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginPhone() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//接受客户端信息
				String phone = request.getParameter("phone");
				phone = new String(phone.getBytes("UTF-8"),"UTF-8");
				System.out.println("根据手机号获得了密码姓名");
				
				//新建服务对象
				Service service = new Service();
					
				//验证处理
				UserBean msg = service.loginphone(phone);
				if( msg!=null ){
					System.out.println("success");
				}else{
					System.out.println("fail");
				}
					
				//返回信息到客户端
				response.setCharacterEncoding("UTF-8");
				response.setContentType("text/html");
				if(msg!=null){
					request.setCharacterEncoding("utf-8");
					response.setCharacterEncoding("utf-8");
					
					JSONObject obj=new JSONObject();
					obj.put("username",msg.getUserName());
					obj.put("userphone",msg.getUserPhone());
					obj.put("userpsw", msg.getUserPsw());
					
					JSONArray array=new JSONArray();
					array.put(obj);
					response.getWriter().append(array.toString());
					
				}else{
					
				}
		}	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

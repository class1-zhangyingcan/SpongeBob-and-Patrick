package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import bean.Scene;
import service.Service;

/**
 * Servlet implementation class SceneLet
 */
@WebServlet("/SceneLet")
public class SceneLet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SceneLet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String scenename = request.getParameter("scenename");
		scenename = new String(scenename.getBytes("UTF-8"),"UTF-8");
		System.out.println(scenename);

		
		//新建服务对象
		Service service = new Service();
		
		//验证处理
		Scene log = service.Scene(scenename);
		System.out.println(log);
		if( log !=null ){
			System.out.println("SceneLet success");
			//request.getSession().setAttribute("username", username);
		}else{
			System.out.println("SceneLet fail");
		}
		
		//返回信息到客户端
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");

		if( log != null ){
//			out.print("sceneimagesrc1：" + sceneimagesrc1);
//			out.print("sceneimagesrc2：" + sceneimagesrc2);
//			out.print("sceneimagesrc3：" + sceneimagesrc3);
	
			request.setCharacterEncoding("utf-8");
			response.setCharacterEncoding("utf-8");
			//模拟多本图书数据
			JSONObject obj1 = new JSONObject();
			try {
				obj1.put("sceneid", log.getSceneid());
				obj1.put("sceneimagesrc1", log.getSceneimagesrc1());
				obj1.put("sceneimagesrc2", log.getSceneimagesrc2());
				obj1.put("sceneimagesrc3", log.getSceneimagesrc3());
				obj1.put("scenename", log.getScenename());
				obj1.put("scenerank", log.getScenerank());
				obj1.put("scenelocation", log.getScenelocation());
				obj1.put("scenedistance", log.getScenedistance());
				obj1.put("sceneopentime", log.getSceneopentime());
				obj1.put("sceneplaytime", log.getSceneplaytime());
				obj1.put("scenemark", log.getScenemark());
			
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
			}
			JSONArray array = new JSONArray();
			array.put(obj1);
			response.getWriter().append(array.toString());
		}else{
			
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

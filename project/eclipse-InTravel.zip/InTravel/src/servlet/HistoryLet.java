package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import bean.History;
import service.Service;


/**
 * Servlet implementation class HistoryLet
 */
@WebServlet("/HistoryLet")
public class HistoryLet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HistoryLet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//新建服务对象
		Service service = new Service();
		List<History> ls=service.History();
		
		JSONArray array = new JSONArray();
		
		for (History history : ls) {
			response.setCharacterEncoding("UTF-8");
			response.setContentType("text/html");
			//打印表中第一列
			System.out.println(history.getHistorytitle());
			
			JSONObject obj1 = new JSONObject();
			obj1.put("historyprice", history.getHistoryprice());
			obj1.put("historydistance", history.getHistorydistance());
			obj1.put("historyimage", history.getHistoryimage());
			obj1.put("historycontent", history.getHistorycontent());
			obj1.put("historyscore", history.getHistoryscore());
			obj1.put("historytitle", history.getHistorytitle());
			System.out.println(obj1.length());
			array.put(obj1);
			
		}
		response.getWriter().append(array.toString());
		System.out.println(array.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import bean.Scenes;
import service.Service;

/**
 * Servlet implementation class ScenesLet
 */
@WebServlet("/ScenesLet")
public class ScenesLet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ScenesLet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		String userphone = request.getParameter("userphone");
//		userphone = new String(userphone.getBytes("ISO-8859-1"), "UTF-8");
//		System.out.println(userphone);
//		
		
		//新建服务对象
		Service service = new Service();
		List<Scenes> ls=service.Scenes();
		
		JSONArray array = new JSONArray();
		
		for (Scenes scenes : ls) {
			response.setCharacterEncoding("UTF-8");
			response.setContentType("text/html");
			//打印表中第一列
			System.out.println(scenes.getScenetitle());
			
			JSONObject obj1 = new JSONObject();
			obj1.put("sceneprice", scenes.getSceneprice());
			obj1.put("scenedistance", scenes.getScenedistance());
			obj1.put("sceneimage", scenes.getSceneimage());
			obj1.put("scenecontent", scenes.getScenecontent());
			obj1.put("scenescore", scenes.getScenescore());
			obj1.put("scenetitle", scenes.getScenetitle());
			System.out.println(obj1.length());
			array.put(obj1);
			
		}
		response.getWriter().append(array.toString());
		System.out.println(array.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

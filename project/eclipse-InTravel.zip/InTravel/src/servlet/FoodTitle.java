package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import bean.FoodBean;
import service.Service;

/**
 * Servlet implementation class FoodLet
 */
@WebServlet("/FoodTitle")
public class FoodTitle extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FoodTitle() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//鎺ュ彈瀹㈡埛绔俊鎭�
		String foodtitle = request.getParameter("foodtitle");
		foodtitle = new String(foodtitle.getBytes("UTF-8"),"UTF-8");
		System.out.println(foodtitle);

		
		//鏂板缓鏈嶅姟瀵硅薄
		Service service = new Service();
			
		//楠岃瘉澶勭悊
		FoodBean msg = service.foodtitle(foodtitle);
		if( msg!=null ){
			System.out.println("success");
		}else{
			System.out.println("fail");
		}
			
		//杩斿洖淇℃伅鍒板鎴风
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		if(msg!=null){
			request.setCharacterEncoding("utf-8");
			response.setCharacterEncoding("utf-8");
			
			JSONObject obj=new JSONObject();
			obj.put("foodimagesrc1",msg.getFoodimagesrc1());
			obj.put("foodimagesrc2",msg.getFoodimagesrc2());
			obj.put("foodimagesrc3",msg.getFoodimagesrc3());
			obj.put("foodtitle",msg.getFoodtitle());
			obj.put("foodcontent",msg.getFoodcontent());
			obj.put("foodscore",msg.getFoodscore());
			obj.put("foodaddress",msg.getFoodaddress());
			obj.put("foodtime",msg.getFoodtime());
			obj.put("foodlist",msg.getFoodlist());
			obj.put("fooddish",msg.getFooddish());
			
			
			JSONArray array=new JSONArray();
			array.put(obj);
			response.getWriter().append(array.toString());
			
		}else{
			
		}
}	

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

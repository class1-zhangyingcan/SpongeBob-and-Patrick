package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import bean.MineBean;
import service.Service;

/**
 * Servlet implementation class LoginPhone
 */
@WebServlet("/PhoneSelect")
public class PhoneSelect extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PhoneSelect() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//接受客户端信息
				String phone = request.getParameter("phone");
				phone = new String(phone.getBytes("UTF-8"),"UTF-8");
				//System.out.println(phone);
				
				//新建服务对象
				Service service = new Service();
					
				//验证处理
				MineBean msg = service.phoneselect(phone);
				if( msg!=null ){
					System.out.println("success");
				}else{
					System.out.println("fail");
				}
					
				//返回信息到客户端
				response.setCharacterEncoding("UTF-8");
				response.setContentType("text/html");
				if(msg!=null){
					request.setCharacterEncoding("utf-8");
					response.setCharacterEncoding("utf-8");
					
					JSONObject obj=new JSONObject();
					obj.put("usermark",msg.getUserMark());
					obj.put("usersex",msg.getUserSex());
					obj.put("useremail",msg.getUserEmail());
					obj.put("userphone",msg.getUserPhone());
					
					JSONArray array=new JSONArray();
					array.put(obj);
					response.getWriter().append(array.toString());
					
				}else{
					
				}
		}	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

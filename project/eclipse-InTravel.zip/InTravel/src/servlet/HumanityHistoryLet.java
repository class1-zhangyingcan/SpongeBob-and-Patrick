package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import service.Service;
import bean.Foodculture;
import bean.Humanityhistory;

/**
 * Servlet implementation class HumanityHistoryLet
 */
@WebServlet("/HumanityHistoryLet")
public class HumanityHistoryLet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HumanityHistoryLet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//鏂板缓鏈嶅姟瀵硅薄
				Service service = new Service();
				List<Humanityhistory> ls=service.Humanityhistory();
				
				JSONArray array = new JSONArray();
				
				for (Humanityhistory humanityhistorys : ls) {
					response.setCharacterEncoding("UTF-8");
					response.setContentType("text/html");
					//鎵撳嵃琛ㄤ腑绗竴鍒�
					System.out.println(humanityhistorys.getHumanitycontent());
					
					JSONObject obj1 = new JSONObject();
					obj1.put("humanityhistorydistance", humanityhistorys.getHumanitydistance());
					obj1.put("humanityhistoryimage", humanityhistorys.getHumanityimage());
					obj1.put("humanityhistorycontent", humanityhistorys.getHumanitycontent());
					obj1.put("humanityhistoryscore", humanityhistorys.getHumanityscore());
					obj1.put("humanityhistorytitle", humanityhistorys.getHumanitytitle());
					System.out.println(obj1.length());
					array.put(obj1);
					
				}
				response.getWriter().append(array.toString());
				System.out.println(array.toString());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

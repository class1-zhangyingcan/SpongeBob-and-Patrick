package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import bean.ParkBean;
import service.Service;

/**
 * Servlet implementation class ParkLet
 */
@WebServlet("/ParkLet")
public class ParkLet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ParkLet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//鎺ュ彈瀹㈡埛绔俊鎭�
				String parkname= request.getParameter("parkname");
				parkname = new String(parkname.getBytes("UTF-8"),"UTF-8");
				System.out.println(parkname);

				
				//鏂板缓鏈嶅姟瀵硅薄
				Service service = new Service();
					
				//楠岃瘉澶勭悊
				ParkBean msg = service.park(parkname);
				if( msg!=null ){
					System.out.println("success");
				}else{
					System.out.println("fail");
				}
					
				//杩斿洖淇℃伅鍒板鎴风
				response.setCharacterEncoding("UTF-8");
				response.setContentType("text/html");
				if(msg!=null){
					request.setCharacterEncoding("utf-8");
					response.setCharacterEncoding("utf-8");
					
					JSONObject obj=new JSONObject();
					obj.put("parkimagesrc1",msg.getParkimagesrc1());
					obj.put("parkimagesrc2",msg.getParkimagesrc2());
					obj.put("parkimagesrc3",msg.getParkimagesrc3());
					obj.put("parkname",msg.getParkname());
					obj.put("parkcontent",msg.getParkcontent());
					obj.put("parkscore",msg.getParkscore());
					obj.put("parkdistance",msg.getParkdistance());
					obj.put("parklocation",msg.getParklocation());
					obj.put("parkopentime",msg.getParkopentime());

					
					
					JSONArray array=new JSONArray();
					array.put(obj);
					response.getWriter().append(array.toString());
					
				}else{
					
				}
		}	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

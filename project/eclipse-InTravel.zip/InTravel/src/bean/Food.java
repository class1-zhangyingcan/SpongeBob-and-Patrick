package bean;

public class Food {
    public int foodid;
    public String foodtitle;
    public String foodscore;
    public String foodcontent;
    public String foodimage;
    public String fooddistance;
    public String foodprice;

    public int getFoodid() {
        return foodid;
    }

    public void setFoodid(int foodid) {
        this.foodid = foodid;
    }

    public String getFoodtitle() {
        return foodtitle;
    }

    public void setFoodtitle(String foodtitle) {
        this.foodtitle = foodtitle;
    }

    public String getFoodscore() {
        return foodscore;
    }

    public void setFoodscore(String foodscore) {
        this.foodscore = foodscore;
    }

    public String getFoodcontent() {
        return foodcontent;
    }

    public void setFoodcontent(String foodcontent) {
        this.foodcontent = foodcontent;
    }

    public String getFoodimage() {
        return foodimage;
    }

    public void setFoodimage(String foodimage) {
        this.foodimage = foodimage;
    }

    public String getFooddistance() {
        return fooddistance;
    }

    public void setFooddistance(String fooddistance) {
        this.fooddistance = fooddistance;
    }

    public String getFoodprice() {
        return foodprice;
    }

    public void setFoodprice(String foodprice) {
        this.foodprice = foodprice;
    }

    public Food() {
    }

    public Food(int foodid, String foodtitle, String foodscore, String foodcontent, String foodimage, String fooddistance, String foodprice) {
        this.foodid = foodid;
        this.foodtitle = foodtitle;
        this.foodscore = foodscore;
        this.foodcontent = foodcontent;
        this.foodimage = foodimage;
        this.fooddistance = fooddistance;
        this.foodprice = foodprice;
    }
}

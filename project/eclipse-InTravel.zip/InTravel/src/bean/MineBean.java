package bean;

public class MineBean {
private int UserId;
private String UserMark;
private String UserSex;
private String UserEmail;
private String UserPhone;
private String UserImage;
public int getUserId() {
	return UserId;
}
public void setUserId(int userId) {
	UserId = userId;
}
public String getUserMark() {
	return UserMark;
}
public void setUserMark(String userMark) {
	UserMark = userMark;
}
public String getUserSex() {
	return UserSex;
}
public void setUserSex(String userSex) {
	UserSex = userSex;
}
public String getUserEmail() {
	return UserEmail;
}
public void setUserEmail(String userEmail) {
	UserEmail = userEmail;
}
public String getUserPhone() {
	return UserPhone;
}
public void setUserPhone(String userPhone) {
	UserPhone = userPhone;
}
public String getUserImage() {
	return UserImage;
}
public void setUserImage(String userImage) {
	UserImage = userImage;
}

}

package bean;

public class Naturalscene {
    public int naturalsceneid;
    public String naturalscenetitle;
    public String naturalscenescore;
    public String naturalscenecontent;
    public String naturalsceneimage;
    public String naturalscenedistance;
    public String naturalsceneprice;

    public int getNaturalsceneid() {
        return naturalsceneid;
    }

    public void setNaturalsceneid(int naturalsceneid) {
        this.naturalsceneid = naturalsceneid;
    }

    public String getNaturalscenetitle() {
        return naturalscenetitle;
    }

    public void setNaturalscenetitle(String naturalscenetitle) {
        this.naturalscenetitle = naturalscenetitle;
    }

    public String getNaturalscenescore() {
        return naturalscenescore;
    }

    public void setNaturalscenescore(String naturalscenescore) {
        this.naturalscenescore = naturalscenescore;
    }

    public String getNaturalscenecontent() {
        return naturalscenecontent;
    }

    public void setNaturalscenecontent(String naturalscenecontent) {
        this.naturalscenecontent = naturalscenecontent;
    }

    public String getNaturalsceneimage() {
        return naturalsceneimage;
    }

    public void setNaturalsceneimage(String naturalsceneimage) {
        this.naturalsceneimage = naturalsceneimage;
    }

    public String getNaturalscenedistance() {
        return naturalscenedistance;
    }

    public void setNaturalscenedistance(String naturalscenedistance) {
        this.naturalscenedistance = naturalscenedistance;
    }

    public String getNaturalsceneprice() {
        return naturalsceneprice;
    }

    public void setNaturalsceneprice(String naturalsceneprice) {
        this.naturalsceneprice = naturalsceneprice;
    }

    public Naturalscene() {
    }

    public Naturalscene(int naturalsceneid, String naturalscenetitle, String naturalscenescore, String naturalscenecontent, String naturalsceneimage, String naturalscenedistance, String naturalsceneprice) {
        this.naturalsceneid = naturalsceneid;
        this.naturalscenetitle = naturalscenetitle;
        this.naturalscenescore = naturalscenescore;
        this.naturalscenecontent = naturalscenecontent;
        this.naturalsceneimage = naturalsceneimage;
        this.naturalscenedistance = naturalscenedistance;
        this.naturalsceneprice = naturalsceneprice;
    }

}


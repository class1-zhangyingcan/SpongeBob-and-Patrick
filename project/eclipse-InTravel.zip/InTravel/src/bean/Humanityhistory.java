package bean;

public class Humanityhistory {
    public int humanityid;
    public String humanitytitle;
    public String humanityscore;
    public String humanitycontent;
    public String humanityimage;
    public String humanitydistance;
    public String humanityprice;

    public int getHumanityid() {
        return humanityid;
    }

    public void setHumanityid(int humanityid) {
        this.humanityid = humanityid;
    }

    public String getHumanitytitle() {
        return humanitytitle;
    }

    public void setHumanitytitle(String humanitytitle) {
        this.humanitytitle = humanitytitle;
    }

    public String getHumanityscore() {
        return humanityscore;
    }

    public void setHumanityscore(String humanityscore) {
        this.humanityscore = humanityscore;
    }

    public String getHumanitycontent() {
        return humanitycontent;
    }

    public void setHumanitycontent(String humanitycontent) {
        this.humanitycontent = humanitycontent;
    }

    public String getHumanityimage() {
        return humanityimage;
    }

    public void setHumanityimage(String humanityimage) {
        this.humanityimage = humanityimage;
    }

    public String getHumanitydistance() {
        return humanitydistance;
    }

    public void setHumanitydistance(String humanitydistance) {
        this.humanitydistance = humanitydistance;
    }

    public String getHumanityprice() {
        return humanityprice;
    }

    public void setHumanityprice(String humanityprice) {
        this.humanityprice = humanityprice;
    }

    public Humanityhistory() {
    }

    public Humanityhistory(int humanityid, String humanitytitle, String humanityscore, String humanitycontent, String humanityimage, String humanitydistance, String humanityprice) {
        this.humanityid = humanityid;
        this.humanitytitle = humanitytitle;
        this.humanityscore = humanityscore;
        this.humanitycontent = humanitycontent;
        this.humanityimage = humanityimage;
        this.humanitydistance = humanitydistance;
        this.humanityprice = humanityprice;
    }
}


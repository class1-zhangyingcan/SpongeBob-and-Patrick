package bean;

public class FoodBean {
    private int foodid;
    private String foodimagesrc1;
    private String foodimagesrc2;
    private String foodimagesrc3;
    private String foodtitle;
    private String foodcontent;
    private String foodscore;
    private String foodaddress;
    private String foodtime;
    private String foodlist;
    private String fooddish;
    public int getFoodid() {
        return foodid;
    }
    public void setFoodid(int foodid) {
        this.foodid = foodid;
    }
    public String getFoodimagesrc1() {
        return foodimagesrc1;
    }
    public void setFoodimagesrc1(String foodimagesrc1) {
        this.foodimagesrc1 = foodimagesrc1;
    }
    public String getFoodimagesrc2() {
        return foodimagesrc2;
    }
    public void setFoodimagesrc2(String foodimagesrc2) {
        this.foodimagesrc2 = foodimagesrc2;
    }
    public String getFoodimagesrc3() {
        return foodimagesrc3;
    }
    public void setFoodimagesrc3(String foodimagesrc3) {
        this.foodimagesrc3 = foodimagesrc3;
    }
    public String getFoodtitle() {
        return foodtitle;
    }
    public void setFoodtitle(String foodtitle) {
        this.foodtitle = foodtitle;
    }
    public String getFoodcontent() {
        return foodcontent;
    }
    public void setFoodcontent(String foodcontent) {
        this.foodcontent = foodcontent;
    }
    public String getFoodscore() {
        return foodscore;
    }
    public void setFoodscore(String foodscore) {
        this.foodscore = foodscore;
    }
    public String getFoodaddress() {
        return foodaddress;
    }
    public void setFoodaddress(String foodaddress) {
        this.foodaddress = foodaddress;
    }
    public String getFoodtime() {
        return foodtime;
    }
    public void setFoodtime(String foodtime) {
        this.foodtime = foodtime;
    }
    public String getFoodlist() {
        return foodlist;
    }
    public void setFoodlist(String foodlist) {
        this.foodlist = foodlist;
    }
    public String getFooddish() {
        return fooddish;
    }
    public void setFooddish(String fooddish) {
        this.fooddish = fooddish;
    }


}

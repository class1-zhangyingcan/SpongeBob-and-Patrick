package bean;

public class UserBean {
private int UserId;
private String UserName;
private String UserPhone;
private String UserPsw;
public int getUserId() {
	return UserId;
}
public void setUserId(int userId) {
	UserId = userId;
}
public String getUserName() {
	return UserName;
}
public void setUserName(String userName) {
	UserName = userName;
}
public String getUserPhone() {
	return UserPhone;
}
public void setUserPhone(String userPhone) {
	UserPhone = userPhone;
}
public String getUserPsw() {
	return UserPsw;
}
public void setUserPsw(String userPsw) {
	UserPsw = userPsw;
}

}
